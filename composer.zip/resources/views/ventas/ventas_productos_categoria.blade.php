<div class="row" style="overflow-y: auto;height:370px">
    <div class="panel-group" id="accordion">
        @forelse ($subcategorias as $item0)
            @php
                $class = '';
            @endphp
            <div class="panel panel-default" style="margin:0px">
                <div class="panel-heading" data-toggle="collapse" data-parent="#accordion" href="#collapse{{$item0->id}}" style="cursor:pointer">
                    <h4 class="panel-title">{{$item0->nombre}}</h4>
                </div>

                {{-- <h4 class="text-primary">{{$item0->nombre}}<hr style="margin:0px"></h4> --}}
                <div id="collapse{{$item0->id}}" class="panel-collapse collapse {{$class}}">
                    <div class="panel-body">
                        @foreach ($productos as $item)
                            @if($item0->id==$item->subcategoria_id)
                                @if (!$item->se_almacena || ($item->se_almacena && $item->stock > 0))
                                    @php
                                        $imagen = (!empty($item->imagen)) ? url('storage').'/'.str_replace('.', '_small.', $item->imagen) : url('storage/productos/default.png');
                                    @endphp
                                    <div class="card col-md-3 text-center" style="margin:5px 0px">
                                        <img class="card-img-top img-producto" id="producto-{{$item->id}}" style="width:130px;height:100px;cursor:pointer" src="{{$imagen}}" alt="{{$item->nombre}}"
                                        @if(!$item->se_almacena) onclick="combinar_producto({{$item->id}}, '{{$item->nombre}}')" @endif
                                        ondblclick="agregar_producto({{$item->id}})">

                                        <div class="card-body" style="padding: 4px">
                                            <h4 class="card-title" style="padding: 0px"> <label class="label label-primary">{{$item->nombre}}</label> </h4>
                                        </div>
                                    </div>
                                @endif
                            @endif
                        @endforeach
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        @empty
            <br>
            <h5 class="text-center">No existen productos en ésta categoria.</h5>
        @endforelse
    </div>
</div>
