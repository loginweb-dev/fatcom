<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

use App\Http\Controllers\LoginwebController as LW;
use App\Http\Controllers\OfertasController as Ofertas;
use App\Http\Controllers\ProductosController as Productos;

use App\User;
use App\ClientesCoordenada;
use App\PasarelaPago;
use App\Venta;
use App\Producto;
use App\Subcategoria;
use App\Sucursale;
use App\Localidade;
use App\Cliente;

class LandingPageController extends Controller
{
    public function index(){

        $productos_categoria = [];
        $categorias = DB::table('categorias as c')
                            ->join('subcategorias as s', 's.categoria_id', 'c.id')
                            ->join('productos as p', 'p.subcategoria_id', 's.id')
                            ->join('ecommerce_productos as ec', 'ec.producto_id', 'p.id')
                            ->select('c.*')
                            // ->where('p.deleted_at', NULL)
                            ->where('c.deleted_at', NULL)
                            // ->orderBy('c.nombre', 'DESC')
                            ->distinct()
                            ->limit(5)
                            ->get();
        $subcategorias = [];
        if(count($categorias)>0){
            // Obtener subcategotia de los productos
            foreach ($categorias as $item) {
                $aux = DB::table('subcategorias')
                            ->select('*')
                            ->where('categoria_id', $item->id)
                            ->where('deleted_at', NULL)
                            ->get();
                if(count($aux)>0){
                    $subcategoria = $aux;
                }else{
                    $subcategoria = [];
                }
                array_push($subcategorias, ['subcategoria' => $subcategoria]);
            }
        }

        $marcas = DB::table('marcas as m')
                            ->join('productos as p', 'p.marca_id', 'm.id')
                            ->join('ecommerce_productos as ec', 'ec.producto_id', 'p.id')
                            ->select(DB::raw('m.id, m.nombre, count(p.id) as productos'))
                            ->where('m.deleted_at', NULL)
                            ->groupBy('id', 'nombre')
                            ->orderBy('productos', 'DESC')
                            ->limit(5)
                            ->get();
        $ofertas = (new Ofertas)->get_ofertas();    
        // dd($ofertas);
    
        $subcategoria_productos = DB::table('subcategorias as s')
                                    ->join('productos as p', 'p.subcategoria_id', 's.id')
                                    ->join('ecommerce_productos as e', 'e.producto_id', 'p.id')
                                    ->select('s.id', 's.nombre', 's.slug')
                                    ->where('s.deleted_at', NULL)
                                    ->distinct()
                                    ->get();
        foreach ($subcategoria_productos as $item) {
            $aux = DB::table('productos as p')
                            ->join('subcategorias as s', 's.id', 'p.subcategoria_id')
                            ->join('ecommerce_productos as e', 'e.producto_id', 'p.id')
                            ->select('p.id', 'p.nombre', 'p.imagen', 'p.nuevo', 'p.slug')
                            // ->where('deleted_at', NULL)
                            ->where('s.id', $item->id)
                            ->where('e.deleted_at', NULL)
                            ->get();

            array_push($productos_categoria, $aux);
        }

        return view('ecommerce/index', compact('ofertas', 'subcategoria_productos', 'productos_categoria', 'marcas', 'categorias', 'subcategorias'));
    }

    public function search(Request $data){
        // dd($data);
        $sentencia = '1';
        $precio_min = $data->min;
        $precio_max = $data->max;

        if($data->tipo_busqueda=='click'){
            $filtro_marca = ($data->marca_id != '') ? ' p.marca_id = '.$data->marca_id : ' 1';
            $filtro_subcategoria = ($data->subcategoria_id != '') ? ' and p.subcategoria_id = '.$data->subcategoria_id : ' and 1';
            $sentencia = $filtro_marca.$filtro_subcategoria;

            // filtro de precios
            if(empty($precio_min) && !empty($precio_max)){
                $sentencia .= " and p.precio_venta < $precio_max";
            }else if(!empty($precio_min) && empty($precio_max)){
                $sentencia .= " and p.precio_venta > $precio_min";
            }else if(!empty($precio_min) && !empty($precio_max)){
                $sentencia .= " and p.precio_venta between $precio_min and $precio_max ";
            }

        }

        if($data->tipo_busqueda=='text'){
            // dd($data);
            if($data->tipo_dato=='all'){
                $sentencia = "( p.nombre like '%".$data->dato."%' or c.nombre like '%".$data->dato."%' or m.nombre like '%".$data->dato."%')";
            }else{
                $sentencia = " ".$data->tipo_dato.".nombre like '%".$data->dato."%' ";
            }
        }

        $productos = DB::table('productos as p')
                            ->join('ecommerce_productos as e', 'e.producto_id', 'p.id')
                            ->join('subcategorias as s', 's.id', 'p.subcategoria_id')
                            ->join('categorias as c', 'c.id', 's.categoria_id')
                            ->join('marcas as m', 'm.id', 'p.marca_id')
                            ->join('tallas as t', 't.id', 'p.talla_id')
                            ->join('colores as co', 'co.id', 'p.color_id')
                            ->join('usos as u', 'u.id', 'p.uso_id')
                            ->join('generos as g', 'g.id', 'p.genero_id')
                            ->join('monedas as mn', 'mn.id', 'p.moneda_id')
                            ->select('p.id', 'p.nombre', 'p.precio_venta', 'p.imagen', 'modelo', 'p.garantia', 'p.descripcion_small', 'p.vistas', 'p.slug', 's.nombre as subcategoria', 'm.nombre as marca', 'mn.abreviacion as moneda', 'u.nombre as uso', 'co.nombre as color', 'g.nombre as genero')
                            // ->where('deleted_at', NULL)
                            ->whereRaw($sentencia)
                            ->where('s.deleted_at', NULL)
                            ->where('m.deleted_at', NULL)
                            ->where('e.deleted_at', NULL)
                            ->paginate(5);
        $precios = [];
        $ofertas = [];
        $puntuaciones = [];
        foreach ($productos as $item) {
            // Obtener precios de venta del producto
            $producto_unidades =  (new Productos)->obtener_precios_venta($item->id);
            $precio = (count($producto_unidades)>0) ? ['precio' => $producto_unidades[0]->precio, 'unidad' => $producto_unidades[0]->unidad] : ['precio' => 0, 'unidad' => 'No definida'];
            array_push($precios, $precio);

            // Obtener si el producto está en oferta
            $oferta = (new Ofertas)->obtener_oferta($item->id);
            array_push($ofertas, ['oferta'=>$oferta]);

            // Obtener puntuaciones
            $puntuacion = (new Productos)->obtener_puntos($item->id);
            array_push($puntuaciones, ['puntos'=>$puntuacion]);
        }

        return view('ecommerce/busqueda', compact('productos', 'precios', 'ofertas', 'precio_min', 'precio_max', 'puntuaciones'));
    }

    public function ofertas(){
        $productos = (new Ofertas)->get_ofertas();
        $precios = [];
        $puntuaciones = [];
        foreach ($productos as $item) {
            // Obtener precios de venta del producto
            $producto_unidades =  (new Productos)->obtener_precios_venta($item->id);
            $precio = (count($producto_unidades)>0) ? ['precio' => $producto_unidades[0]->precio, 'unidad' => $producto_unidades[0]->unidad] : ['precio' => 0, 'unidad' => 'No definida'];
            array_push($precios, $precio);

            // Obtener puntuaciones
            $puntuacion = (new Productos)->obtener_puntos($item->id);
            array_push($puntuaciones, ['puntos'=>$puntuacion]);
        }

        $recomendaciones = DB::table('productos as p')
                                ->join('ofertas_detalles as df', 'df.producto_id', 'p.id')
                                ->join('ofertas as o', 'o.id', 'df.oferta_id')
                                ->select('p.id', 'p.nombre', 'p.imagen', 'p.slug')
                                ->where('o.inicio', '<', Carbon::now())
                                ->whereRaw(" (o.fin is NULL or o.fin > '".Carbon::now()."')")
                                ->where('df.deleted_at', NULL)
                                ->where('o.deleted_at', NULL)
                                ->limit(10)
                                ->get();

        return view('ecommerce/ofertas', compact('productos', 'precios', 'puntuaciones', 'recomendaciones'));
    }

    public function subcategorias(Subcategoria $subcategoria){
        $id = $subcategoria->id;
        $subcategoria = DB::table('subcategorias')->select('nombre', 'slug')->where('id', $id)->first();

        $productos = DB::table('productos as p')
                            ->join('ecommerce_productos as e', 'e.producto_id', 'p.id')
                            ->join('subcategorias as s', 's.id', 'p.subcategoria_id')
                            ->join('categorias as c', 'c.id', 's.categoria_id')
                            ->join('marcas as m', 'm.id', 'p.marca_id')
                            ->join('tallas as t', 't.id', 'p.talla_id')
                            ->join('colores as co', 'co.id', 'p.color_id')
                            ->join('usos as u', 'u.id', 'p.uso_id')
                            ->join('generos as g', 'g.id', 'p.genero_id')
                            ->join('monedas as mn', 'mn.id', 'p.moneda_id')
                            ->select('p.id', 'p.nombre', 'p.imagen', 'modelo', 'p.garantia', 'p.descripcion_small', 'p.slug', 's.nombre as subcategoria', 'm.nombre as marca', 'mn.abreviacion as moneda', 'u.nombre as uso', 'co.nombre as color', 'g.nombre as genero')
                            // ->where('deleted_at', NULL)
                            ->where('s.deleted_at', NULL)
                            ->where('m.deleted_at', NULL)
                            ->where('e.deleted_at', NULL)
                            ->where('p.subcategoria_id', $id)
                            ->paginate(5);
        $precios = [];
        $ofertas = [];
        $puntuaciones = [];
        foreach ($productos as $item) {
            // Obtener precios de venta del producto
            $producto_unidades =  (new Productos)->obtener_precios_venta($item->id);
            $precio = (count($producto_unidades)>0) ? ['precio' => $producto_unidades[0]->precio, 'unidad' => $producto_unidades[0]->unidad] : ['precio' => 0, 'unidad' => 'No definida'];
            array_push($precios, $precio);

            // Obtener si el producto está en oferta
            $oferta = (new Ofertas)->obtener_oferta($item->id);
            array_push($ofertas, ['oferta'=>$oferta]);

            // Obtener puntuaciones
            $puntuacion = (new Productos)->obtener_puntos($item->id);
            array_push($puntuaciones, ['puntos'=>$puntuacion]);
        }

        $recomendaciones = DB::table('productos as p')
                                ->select('p.id', 'p.nombre', 'p.imagen', 'p.slug')
                                ->where('p.subcategoria_id', $id)
                                ->limit(10)
                                ->get();

        return view('ecommerce/subcategorias', compact('productos', 'precios', 'ofertas', 'puntuaciones', 'recomendaciones', 'subcategoria', 'id'));
    }

    public function detalle_producto(Producto $producto){
        $id = $producto->id;
        // Incrementar numero de vistas a producto
        DB::table('productos')->where('id', $id)->increment('vistas', 1);

        $producto = DB::table('productos as p')
                            ->join('subcategorias as s', 's.id', 'p.subcategoria_id')
                            ->join('marcas as m', 'm.id', 'p.marca_id')
                            ->join('tallas as t', 't.id', 'p.talla_id')
                            ->join('colores as c', 'c.id', 'p.color_id')
                            ->join('usos as u', 'u.id', 'p.uso_id')
                            ->join('generos as g', 'g.id', 'p.genero_id')
                            ->join('monedas as mn', 'mn.id', 'p.moneda_id')
                            ->join('ecommerce_productos as ec', 'ec.producto_id', 'p.id')
                            ->select('p.id', 'p.nombre', 'p.precio_venta', 'p.imagen', 'p.modelo', 'p.garantia', 'p.descripcion_small', 'p.descripcion_long', 'p.vistas', 'p.catalogo', 'p.slug', 's.nombre as subcategoria', 'm.nombre as marca', 'mn.abreviacion as moneda', 'u.nombre as uso', 'c.nombre as color', 'g.nombre as genero', 'ec.tags')
                            // ->where('deleted_at', NULL)
                            ->where('p.id', $id)
                            ->first();
        $imagenes = DB::table('producto_imagenes')
                            ->select('imagen')
                            ->where('producto_id', $id)
                            ->where('deleted_at', NULL)
                            ->orderBy('tipo', 'ASC')
                            // ->where('tipo', 'principal')
                            ->get();
        $precios_venta = (new Productos)->obtener_precios_venta($id);

        $puntuacion = (new Productos)->obtener_puntos($id);

        $habilitar_puntuar = null;
        if(isset(Auth::user()->id)){
            $habilitar_puntuar = DB::table('productos_puntuaciones')
                                        ->select('id')
                                        ->where('user_id', Auth::user()->id)
                                        ->where('producto_id', $id)
                                        ->where('deleted_at', NULL)
                                        ->first();
        }

        // Recomendaciones
        $tags = explode(',', $producto->tags);
        $recomendaciones = [];
        foreach ($tags as $item) {
            $array = DB::table('productos as p')
                            ->join('ecommerce_productos as ec', 'ec.producto_id', 'p.id')
                            ->select('p.id', 'p.nombre', 'p.imagen', 'p.slug')
                            ->where('ec.tags', 'like', "%$item%")
                            ->where('p.id', '<>', $id)
                            ->get();
            foreach ($array as $item2) {
                $existe = false;
                $indice = 0;
                for($i=0; $i<count($recomendaciones); $i++){
                    if($recomendaciones[$i]['id']==$item2->id){
                        $existe = true;
                        $indice = $i;
                    }
                }

                if($existe){
                    $recomendaciones[$indice]['coincidencias']++;
                }else{
                    array_push($recomendaciones, ['id'=>$item2->id, 'nombre'=>$item2->nombre, 'imagen'=>$item2->imagen, 'slug'=>$item2->slug, 'coincidencias'=>1]);
                }
            }
        }
        // Ordenar lista segun las coincidencias
        for ($i=0; $i < count($recomendaciones); $i++) {
            for ($j=$i+1; $j < count($recomendaciones); $j++) {
                if($recomendaciones[$i]['coincidencias'] < $recomendaciones[$j]['coincidencias']){

                    $aux_id = $recomendaciones[$i]['id'];
                    $recomendaciones[$i]['id'] = $recomendaciones[$j]['id'];
                    $recomendaciones[$j]['id'] = $aux_id;

                    $aux_nombre = $recomendaciones[$i]['nombre'];
                    $recomendaciones[$i]['nombre'] = $recomendaciones[$j]['nombre'];
                    $recomendaciones[$j]['nombre'] = $aux_nombre;

                    $aux_imagen = $recomendaciones[$i]['imagen'];
                    $recomendaciones[$i]['imagen'] = $recomendaciones[$j]['imagen'];
                    $recomendaciones[$j]['imagen'] = $aux_imagen;

                    $aux_slug = $recomendaciones[$i]['slug'];
                    $recomendaciones[$i]['slug'] = $recomendaciones[$j]['slug'];
                    $recomendaciones[$j]['slug'] = $aux_slug;

                    $aux_coincidencia = $recomendaciones[$i]['coincidencias'];
                    $recomendaciones[$i]['coincidencias'] = $recomendaciones[$j]['coincidencias'];
                    $recomendaciones[$j]['coincidencias'] = $aux_coincidencia;
                }
            }
        }
        // ===============

        // Costo de envío segun la localidad en la que se encuentre el cliente
        // NOTA: Si el cliente no se encuentra logueado no se mostrará ningun dato
        $envio = NULL;
        if(Auth::user()){
            if(Auth::user()->localidad_id){
                $ubicacion = DB::table('ecommerce_envios as e')
                                    ->join('localidades as l', 'l.id', 'e.localidad_id')
                                    ->join('ecommerce_productos as ep', 'ep.id', 'e.ecommerce_producto_id')
                                    ->select('l.*', 'e.precio')
                                    ->where('localidad_id', Auth::user()->localidad_id)
                                    ->where('ep.producto_id', $id)
                                    ->where('l.deleted_at', NULL)->where('e.deleted_at', NULL)->first();
                if($ubicacion){
                    $envio = $ubicacion;
                }else{
                    $envio = 'no definido';
                }
            }else{
                $envio = 'no asignado';
            }
        }

        $oferta = (new Ofertas)->obtener_oferta($id);
        $dispositivo = LW::userAgent();

        $localidades_disponibles = DB::table('ecommerce_productos as ep')
                                    ->join('ecommerce_envios as ee', 'ee.ecommerce_producto_id', 'ep.producto_id')
                                    ->join('localidades as l', 'l.id', 'ee.localidad_id')
                                    ->select('l.localidad as ciudad', 'ee.precio')
                                    ->where('l.activo', 1)->where('l.deleted_at', NULL)->where('ep.deleted_at', NULL)->where('ee.deleted_at', NULL)
                                    ->get();
        return view('ecommerce/detalle', compact('producto', 'imagenes', 'precios_venta', 'puntuacion', 'oferta', 'id', 'habilitar_puntuar', 'recomendaciones', 'dispositivo', 'envio', 'localidades_disponibles'));
    }

    public function cantidad_carrito(){
        $carrito = session()->has('carrito_compra') ? session()->get('carrito_compra') : array();
        return count($carrito);
    }

    public function cantidad_pedidos(){
        $pedidos = DB::table('ventas as v')
                        ->join('clientes as c', 'c.id', 'v.cliente_id')
                        ->join('users as u', 'u.cliente_id', 'c.id')
                        ->select('v.id')
                        ->where('u.id', Auth::user()->id)
                        ->where('v.venta_estado_id', '<=', 4)
                        ->get();
        return count($pedidos);
    }

    public function carrito_comprar($id){
        $query =  $this->carrito_agregar($id);
        if($query){
            return redirect()->route('carrito_compra');
        }else{
            return redirect()->route('detalle_producto_ecommerce', ['id' => $id]);
        }
    }

    public function carrito_index(){
        // session()->forget('carrito_compra');
        $cliente_id = isset(Auth::user()->id) ? User::find(Auth::user()->id)->cliente_id : 0;

        $user_coords =  ClientesCoordenada::where('cliente_id', $cliente_id)->where('descripcion', '<>', '')->orderBy('concurrencia', 'DESC')->limit(5)->get();
        $pasarela_pago = PasarelaPago::where('deleted_at', NULL)->get();

        $carrito = session()->has('carrito_compra') ? session()->get('carrito_compra') : array();
        $precios = [];
        $ofertas = [];
        foreach ($carrito as $item) {
            // Ver si esta en oferta
            $oferta = (new Ofertas)->obtener_oferta($item->id);
            array_push($ofertas, $oferta);
        }

        $sucursal = Sucursale::all()->first();

        $disponibles = [];
        foreach ($carrito as $item) {
            $envios = DB::table('ecommerce_productos as ep')
                            ->join('ecommerce_envios as ee', 'ee.ecommerce_producto_id', 'ep.id')
                            ->select('ep.producto_id as id', 'ee.precio as costo_envio', 'ee.localidad_id')
                            ->where('ep.producto_id', $item->id)->where('ee.deleted_at', NULL)->first();
            if($envios){
                array_push($disponibles, $envios);
            }
        }
        // dd($disponibles);
        return view('ecommerce/carrito', compact('carrito', 'precios', 'ofertas', 'user_coords', 'pasarela_pago', 'cliente_id', 'sucursal', 'disponibles'));
    }

    public function get_precio($id, $cantidad){
        $aux = DB::table('producto_unidades as pu')
                        ->join('productos as p', 'p.id', 'pu.producto_id')
                        ->join('monedas as m', 'm.id', 'p.moneda_id')
                        ->select('pu.precio', 'pu.cantidad_minima', 'm.abreviacion as moneda')
                        ->where('pu.producto_id', $id)
                        ->where('pu.cantidad_minima', '>=', $cantidad)
                        ->orderBy('pu.cantidad_minima', 'ASC')
                        ->first();
        if($aux){
            if($aux->cantidad_minima == $cantidad){
                return response()->json($aux);
            }else{
                $registro = DB::table('producto_unidades as pu')
                            ->join('productos as p', 'p.id', 'pu.producto_id')
                            ->join('monedas as m', 'm.id', 'p.moneda_id')
                            ->select('pu.precio', 'pu.cantidad_minima', 'm.abreviacion as moneda')
                            ->where('pu.producto_id', $id)
                            ->where('pu.cantidad_minima', '<', $aux->cantidad_minima)
                            ->orderBy('pu.cantidad_minima', 'DESC')
                            ->first();
                return response()->json($registro);
            }
        }
        $registro = DB::table('producto_unidades as pu')
                            ->join('productos as p', 'p.id', 'pu.producto_id')
                            ->join('monedas as m', 'm.id', 'p.moneda_id')
                            ->select('pu.precio', 'pu.cantidad_minima', 'm.abreviacion as moneda')
                            ->where('pu.producto_id', $id)
                            ->orderBy('pu.cantidad_minima', 'DESC')
                            ->first();
            return response()->json($registro);
    }

    public function carrito_agregar($id){
        $carrito = session()->has('carrito_compra') ? session()->get('carrito_compra') : array();

        $producto = DB::table('productos as p')
                            ->join('subcategorias as s', 's.id', 'p.subcategoria_id')
                            ->join('marcas as m', 'm.id', 'p.marca_id')
                            ->join('tallas as t', 't.id', 'p.talla_id')
                            ->join('colores as c', 'c.id', 'p.color_id')
                            ->join('usos as u', 'u.id', 'p.uso_id')
                            ->join('generos as g', 'g.id', 'p.genero_id')
                            ->join('monedas as mn', 'mn.id', 'p.moneda_id')
                            ->join('ecommerce_productos as ec', 'ec.producto_id', 'p.id')
                            ->select('p.id', 'p.codigo', 'p.nombre', 'p.precio_venta', 'p.imagen', 'p.modelo', 'p.garantia', 'p.descripcion_small', 'p.slug', 'm.nombre as marca', 'mn.abreviacion as moneda', 'u.nombre as uso', 'c.nombre as color', 'g.nombre as genero')
                            // ->where('deleted_at', NULL)
                            ->where('p.id', $id)
                            ->first();
        if($producto){
            $carrito[$id] = $producto;
            session()->put('carrito_compra', $carrito);
            return 1;
        }else{
            return 0;
        }
    }

    public function carrito_borrar($id){
        // session()->forget('carrito_compra');
        $carrito = session()->has('carrito_compra') ? session()->get('carrito_compra') : array();
        $carrito_aux = array();
        foreach ($carrito as $item) {
            if($item->id!=$id){
                array_push($carrito_aux, $item);
            }
        }
        session()->put('carrito_compra', $carrito_aux);
        $alerta = 'producto_eliminado';
        return redirect()->route('carrito_compra')->with(compact('alerta'));
    }

    public function pedidos_index($id){
        $sentencia = ($id!='last') ? " v.id = $id" : 1;
        $ultimo_pedido = DB::table('ventas as v')
                                ->join('clientes as c', 'c.id', 'v.cliente_id')
                                ->join('users as u', 'u.cliente_id', 'c.id')
                                ->join('ventas_estados as ve', 've.id', 'v.venta_estado_id')
                                ->select('v.id', 'v.venta_estado_id')
                                ->where('u.id', Auth::user()->id)
                                ->whereRaw($sentencia)
                                ->orderBy('id', 'DESC')
                                ->first();
        if($ultimo_pedido){
            $mi_ubicacion = DB::table('clientes_coordenadas as cc')
                                ->join('clientes as c', 'c.id', 'cc.cliente_id')
                                ->join('users as u', 'u.cliente_id', 'c.id')
                                ->select('cc.lat', 'cc.lon')
                                ->where('u.id', Auth::user()->id)
                                ->where('cc.ultima_ubicacion', 1)
                                ->first();
            $detalle_pedido = DB::table('ventas_detalles as dv')
                                    ->join('productos as p', 'p.id', 'dv.producto_id')
                                    ->join('monedas as m', 'm.id', 'p.moneda_id')
                                    ->select('p.*', 'dv.cantidad as cantidad_pedido', 'dv.precio as precio_pedido', 'm.abreviacion as moneda')
                                    ->where('dv.venta_id', $ultimo_pedido->id)
                                    ->get();

            $pedidos = DB::table('ventas as v')
                            ->join('clientes as c', 'c.id', 'v.cliente_id')
                            ->join('users as u', 'u.cliente_id', 'c.id')
                            ->select('v.id', 'v.venta_estado_id', 'v.created_at')
                            ->where('u.id', Auth::user()->id)
                            ->orderBy('id', 'DESC')
                            ->get();
            $productos_pedidos = [];
            foreach ($pedidos as $item) {
                $aux = DB::table('ventas_detalles as dv')
                            ->join('productos as p', 'p.id', 'dv.producto_id')
                            ->select('p.nombre')
                            ->where('dv.venta_id', $item->id)
                            ->get();
                array_push($productos_pedidos, $aux);
            }
        }

        if($ultimo_pedido){
            return view('ecommerce/pedidos', compact('ultimo_pedido', 'mi_ubicacion', 'detalle_pedido', 'pedidos', 'productos_pedidos'));
        }else{
            return view('ecommerce/pedidos_empty');
        }
    }

    public function get_estado_pedido($id){
        return response()->json(DB::table('ventas as v')
                                ->join('clientes as c', 'c.id', 'v.cliente_id')
                                ->join('users as u', 'u.cliente_id', 'c.id')
                                ->join('ventas_estados as ve', 've.id', 'v.venta_estado_id')
                                ->select('v.venta_estado_id as id', 've.nombre', 've.etiqueta')
                                ->where('u.id', Auth::user()->id)
                                ->whereRaw('v.id', $id)
                                ->orderBy('v.id', 'DESC')
                                ->first());
    }

    public function ecommerce_policies(){
        return 'politicas';
    }


    public function profile(){
        $registro = DB::table('users as u')
                            ->join('clientes as c', 'c.id', 'u.cliente_id')
                            ->select('c.*', 'u.localidad_id', 'u.name', 'u.email', 'avatar', 'tipo_login')
                            ->where('c.deleted_at', NULL)->where('u.id', Auth::user()->id)
                            ->first();
        $localidad = $registro->localidad_id ? Localidade::find($registro->localidad_id) : NULL;

        $localidades = Localidade::where('deleted_at', NULL)->get();

        return view('auth.profile', compact('registro', 'localidad', 'localidades'));
    }

    public function profile_update(Request $data){
        // dd($data);
        $user = User::find(Auth::user()->id);
        $user->name = $data->name;
        $user->email = $data->email;
        $user->localidad_id = $data->localidad_id;
        $user->save();

        $cliente = Cliente::find(Auth::user()->cliente_id);
        $cliente->razon_social = $data->razon_social;
        $cliente->nit = $data->nit;
        $cliente->movil = $data->movil;
        $cliente->save();

        $alerta = 'cliente_editado';
        return redirect()->route('profile')->with(compact('alerta'));
    }
}


