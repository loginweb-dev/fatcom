<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class VentasEstado extends Model
{
    
}
