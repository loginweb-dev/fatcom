<?php $__env->startSection('page_title', 'Añadir Empleado'); ?>

<?php if(auth()->user()->hasPermission('add_empleados')): ?>
    <?php $__env->startSection('page_header'); ?>
        <h1 class="page-title">
            <i class="voyager-people"></i> Añadir Empleado
        </h1>
        
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
        <div class="page-content">
            <div class="page-content browse container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-bordered">
                            <form action="<?php echo e(route('empleados_store')); ?>" method="post">
                                <div class="panel-body strong-panel">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="row">
                                                <div class="col-md-6 form-group">
                                                    <label for="">Nombre completo</label> <?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Nombre completo del empleado. este campo es obligatorio."></span> <?php endif; ?>
                                                    <input type="text" name="nombre" class="form-control" value="<?php echo e(old('nombre')); ?>" placeholder="Nombre completo del empleado" required>
                                                    <?php if ($errors->has('nombre')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nombre'); ?>
                                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                                <div class="col-md-6 form-group">
                                                    <label for="">Movil</label> <?php if(setting('admin.tips')): ?> <span class="voyager-question text-default pull-right" data-toggle="tooltip" data-placement="left" title="Número de celular del empleado. este campo no es obligatorio."></span> <?php endif; ?>
                                                    <input type="number" name="movil" class="form-control" value="<?php echo e(old('movil')); ?>" placeholder="Número celular" maxlength="20" >
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12 form-group">
                                                    <label for="">Dirección</label> <?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Dirección de domicilio del empleado. este campo no es obligatorio."></span> <?php endif; ?>
                                                    <textarea name="direccion" id="" class="form-control" maxlength="150" required><?php echo e(old('direccion')); ?></textarea>
                                                    <?php if ($errors->has('direccion')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('direccion'); ?>
                                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6 form-group">
                                                    <label for="">Nickname</label> <?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Nombre del empleado que se visualizará cuando ingrese al sistema. este campo es obligatorio."></span> <?php endif; ?>
                                                    <input type="text" name="nickname" class="form-control" value="<?php echo e(old('nickname')); ?>" placeholder="Nick name del empleado" maxlength="20" required>
                                                    <?php if ($errors->has('nickname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nickname'); ?>
                                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                                <div class="col-md-6 form-group">
                                                    <label for="">Rol del empleado</label> <?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Rol del acceso al sistema que tendrá el empleado. este campo es obligatorio."></span> <?php endif; ?>
                                                    <select name="rol_id" id="select-rol_id" class="form-control" required>
                                                        <option value="">Selecciona el rol</option>
                                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->display_name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6 form-group">
                                                    <label for="">Email</label> <?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Email del empleado que servirá para que ingrese al sistema. este campo es obligatorio."></span> <?php endif; ?>
                                                    <input type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>" placeholder="Email" maxlength="50" required>
                                                    <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                                <div class="col-md-6 form-group">
                                                    <label for="">Password</label> <?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Contraseña del empleado que servirá para que ingrese al sistema. este campo es obligatorio."></span> <?php endif; ?>
                                                    <input type="password" name="password" class="form-control" placeholder="Password" maxlength="20" required>
                                                    <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <button type="submit" class="btn btn-primary">Guardar</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('css'); ?>
        <style>

        </style>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('javascript'); ?>
        <script>
            $(document).ready(function(){
                $('[data-toggle="tooltip"]').tooltip();
                $('#select-rol_id').select2();
            });
        </script>
    <?php $__env->stopSection(); ?>

<?php else: ?>
    <?php $__env->startSection('content'); ?>
        <?php echo $__env->make('errors.sin_permiso', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatcom\resources\views/empleados/empleados_create.blade.php ENDPATH**/ ?>