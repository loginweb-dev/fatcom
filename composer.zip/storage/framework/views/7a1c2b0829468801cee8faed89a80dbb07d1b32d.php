<?php $__env->startSection('page_title', 'Añadir Caja'); ?>

<?php if(auth()->user()->hasPermission('add_cajas')): ?>
    <?php $__env->startSection('page_header'); ?>
        <h1 class="page-title">
            <i class="voyager-treasure"></i> Añadir Caja
        </h1>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
        <div class="page-content">
            <div class="page-content browse container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <form action="<?php echo e(route('cajas_store')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="panel panel-bordered">
                                <div class="panel-body">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Sucursal</label><?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Sucursal en la que se esta aperturando la caja. Este campo es obligatorio."></span> <?php endif; ?>
                                            <select name="sucursal_id" class="form-control select2" id="" required>
                                                <?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->nombre); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="row">
                                            <div class="form-group col-md-6">
                                                <label>Fecha de apertura</label><?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Fecha de apertura de la caja. Este campo es obligatorio."></span> <?php endif; ?>
                                                <input type="date" class="form-control" value="<?php echo e(date('Y-m-d')); ?>" name="fecha" required>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Hora</label> <?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Hora de apertura de la caja. Este campo es obligatorio."></span> <?php endif; ?>
                                                <input type="time" class="form-control" name="hora" value="<?php echo e(date('H:i')); ?>" required>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="form-group col-md-6">
                                                <label>Descripción</label><?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Descripción de la caja. Este campo es obligatorio."></span> <?php endif; ?>
                                                <input type="text" class="form-control" name="nombre" required>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Monto de apertura</label><?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Monto de apertura de la caja, en caso de abrir la caja sin efectivo ingresar 0. Este campo es obligatorio."></span> <?php endif; ?>
                                                <div class="input-group">
                                                    <input type="number" class="form-control" name="monto" value="0" required>
                                                    <span class="input-group-addon">Bs.</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel-footer">
                                    <button type="submit" class="btn btn-primary save">Guardar</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('css'); ?>
        <style>
            .btn-option{
                padding: 0px;
                text-decoration: none;
            }
        </style>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('javascript'); ?>
        <script>
            $(document).ready(function(){
                $('[data-toggle="tooltip"]').tooltip();
            });
        </script>
    <?php $__env->stopSection(); ?>

<?php else: ?>
    <?php $__env->startSection('content'); ?>
        <?php echo $__env->make('errors.sin_permiso', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatcom\resources\views/cajas/cajas_create.blade.php ENDPATH**/ ?>