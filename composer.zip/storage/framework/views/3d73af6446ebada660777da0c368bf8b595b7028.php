<?php $__env->startSection('meta-datos'); ?>
    <title>Carrito de compra - <?php echo e(setting('admin.title')); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('banner'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main id="contenido" class="col-md-8">
    <form id="form_carrito" name="form_carrito" action="<?php echo e(route('pedidos_store')); ?>" method="post">
        <div class="card">
            <div class="table-responsive">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="tipo" value="pedido">
                <table class="table table-hover shopping-cart-wrap">
                    <thead class="text-muted">
                        <tr>
                            
                            <th scope="col">Producto</th>
                            <th scope="col">Cantidad</th>
                            <th scope="col">Precio</th>
                            <th scope="col" class="text-right" width="200">Acción</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $total = 0;
                            $cont = 0;
                        ?>
                        <?php $__empty_1 = true; $__currentLoopData = $carrito; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $imagen = ($item->imagen!='') ? str_replace('.', '_small.', $item->imagen) : 'productos/default.png';
                        ?>
                        <tr>
                            
                            <td>
                                <figure class="media">
                                    <div class="img-wrap"><img src="<?php echo e(url('storage').'/'.$imagen); ?>" class="img-thumbnail img-sm"></div>
                                    <figcaption class="media-body">
                                        <h6 class="title text-truncate"><?php echo e($item->nombre); ?></h6>
                                        <dl class="dlist-inline small">
                                            <dt>Marca : </dt>
                                            <dd> <?php echo e($item->marca); ?></dd><br>
                                            <dt>Modelo : </dt>
                                            <dd> <?php echo e($item->modelo); ?></dd><br>
                                            <dt>Garantía : </dt>
                                            <dd> <?php echo e($item->garantia); ?></dd>
                                        </dl>
                                    </figcaption>
                                </figure>
                            </td>
                            <td><input type="number" style="width:80px" class="form-control" onchange="calcular_total()" onkeyup="calcular_total()" name="cantidad[]" id="input-cantidad<?php echo e($cont); ?>" value="1" min="1" step="1"></td>
                            <td>
                                <?php
                                    $precio_actual = $precios[$cont]['precio'];
                                    $precio_anterior = '';
                                    $moneda = $precios[$cont]['moneda'];
                                    if($ofertas[$cont]){
                                        if($ofertas[$cont]->tipo_descuento=='porcentaje'){
                                            $precio_actual -= ($precio_actual*($ofertas[$cont]->monto/100));
                                        }else{
                                            $precio_actual -= $ofertas[$cont]->monto;
                                        }
                                        $precio_anterior = $moneda.' '.$precios[$cont]['precio'];
                                    }
                                ?>
                                <div class="price-wrap">
                                    <var class="price"><?php echo e($moneda); ?> <?php echo e($precio_actual); ?> <del class="price-old" style="font-size:15px"><?php echo e($precio_anterior); ?></del></var>
                                </div>
                                <input type="hidden" class="form-control" name="precio[]" value="<?php echo e($precio_actual); ?>" id="input-precio<?php echo e($cont); ?>">
                            </td>
                            <td class="text-right">
                                <a href="<?php echo e(url('carrito/borrar').'/'.$item->id); ?>" class="btn btn-outline-danger link-page"> <span class="fa fa-trash"></span></a>
                            </td>
                        </tr>
                        <?php
                            $total += $precio_actual;
                            $cont++;
                        ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center"><span>No se han agregados productos al carro.</span></td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <aside class="col-md-4">
        
        <div class="tab-content" id="pills-tabContent">
            <div class="tab-pane fade show active" id="pills-tab1" role="tabpanel" aria-labelledby="pills-tab1-tab">
                <div style="margin:2px">
                    <?php if(count($user_coords)>0): ?>
                        <h5 class="text-muted">Mis Ubicaciones:</h5>
                        <?php $__currentLoopData = $user_coords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <?php
                                $descripcion = $item->descripcion;
                                if(strlen($descripcion)>30){
                                    $descripcion = substr($descripcion, 0, 30).'...';
                                }
                            ?>

                            <button type="button" class="btn btn-outline-primary btn-coor" data-id="<?php echo e($item->id); ?>" data-lat="<?php echo e($item->lat); ?>" data-lon="<?php echo e($item->lon); ?>" data-descripcion="<?php echo e($item->descripcion); ?>" data-toggle="tooltip" data-placement="top" title="<?php echo e($item->descripcion); ?>"><?php echo e($descripcion); ?></button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <span>No tiene ubicaciones, crea una.</span>
                    <?php endif; ?>
                </div>
                <div id="map"></div>
                <input type="hidden" name="lat" id="latitud" >
                <input type="hidden" name="lon" id="longitud">
                <input type="hidden" name="coordenada_id" id="input-coordenada_id">
                <textarea name="descripcion" class="form-control" id="input-descripcion" rows="2" maxlength="200" placeholder="Datos descriptivos de su ubicación..." required></textarea>
            </div>
            <div class="tab-pane fade" id="pills-tab2" role="tabpanel" aria-labelledby="pills-tab2-tab">...</div>
        </div>
        <hr>
        <div class="text-right">
            <button type="button" data-toggle="modal" data-target="#modal_confirmar" class="btn btn-outline-success">Realizar pedido <span class="fa fa-shopping-cart"></span> </button>
        </div>

        
        <div class="modal modal-info fade" tabindex="-1" id="modal_confirmar" role="dialog">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">
                                <i class="fa fa-shopping-cart"></i> Elija la forma de pago
                            </h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        </div>
                        <div class="modal-body">
                            <div class="col-md-12">
                                <table width="100%" cellpadding="10">
                                    <?php
                                        $checked = 'checked';
                                    ?>
                                    <?php $__currentLoopData = $pasarela_pago; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><input type="radio" <?php echo e($checked); ?> <?php if($item->estado == 0): ?> disabled <?php endif; ?> name="tipo_pago"></td>
                                        <td><img src="<?php echo e(url('storage').'/'.$item->icono); ?>" width="80px" alt="icono"></td>
                                        <td><?php echo e($item->nombre); ?> <br> <b><?php echo e($item->descripcion); ?></b></td>
                                    </tr>
                                    <?php
                                        $checked = '';
                                    ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <input type="submit" class="btn btn-info pull-right delete-confirm"value="Confirmar">
                            <button type="button" class="btn btn-default pull-right" data-dismiss="modal">Cancelar</button>
                        </div>
                    </div>
                </div>
            </div>
        
    </form>
    </aside>
<?php $__env->stopSection(); ?>
<script>
    let cantidad = parseInt('<?php echo e($cont); ?>');
    function calcular_total(){
        let total = 0;
        for (let i = 0; i < cantidad; i++) {
            total += parseInt($('#input-cantidad'+i).val()) * $('#input-precio'+i).val();
        }
        $('#label-total').html('Bs. '+total.toFixed(2));
        $('#input-importe').val(total)
    }

    // function enviar_carrito(){
    //     document.form_carrito.submit()
    // }
</script>


    
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.5.1/dist/leaflet.css" integrity="sha512-xwE/Az9zrjBIphAcBb3F6JVqxf46+CDLwfLMHloNu6KEQCAWi6HcDUbeOfBIptF7tcCzusKFjFw2yuvEpDL9wQ==" crossorigin=""/>
    <style>
        #map {
            height: 300px;
        }
    </style>
    <script src="<?php echo e(url('ecommerce/js/jquery-2.0.0.min.js')); ?>" type="text/javascript"></script>
    <script src="https://unpkg.com/leaflet@1.5.1/dist/leaflet.js" integrity="sha512-GffPMF3RvMeYyc1LWMHtK8EbPv0iNZ8/oTtHPx9/cc2ILxQ+u905qIwdpULaqDkyBKgOaB57QTMg7ztg8Jm2Og==" crossorigin=""></script>
    <script src="<?php echo e(url('js/ubicacion_cliente.js')); ?>" type="text/javascript"></script>
    <script>
        let marcador = {};
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();
        });
    </script>


<?php echo $__env->make('ecommerce.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatcom\resources\views/ecommerce/computacion_electronica/carrito.blade.php ENDPATH**/ ?>