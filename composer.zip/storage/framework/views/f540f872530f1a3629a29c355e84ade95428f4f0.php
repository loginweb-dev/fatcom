<?php $__env->startSection('page_title', 'Añadir Dosificación'); ?>

<?php if(auth()->user()->hasPermission('add_dosificaciones')): ?>
    <?php $__env->startSection('page_header'); ?>
        <h1 class="page-title">
            <i class="voyager-key"></i> Añadir Dosificación
        </h1>
        
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>
        <div class="page-content">
            <div class="page-content browse container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-bordered">
                            <form action="<?php echo e(route('dosificaciones_store')); ?>" method="post">
                                <div class="panel-body strong-panel">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="form-group col-md-6">
                                            <label for="">N&deg; de autorización</label>
                                            <input type="text" name="nro_autorizacion" value="<?php echo e(old('nro_autorizacion')); ?>" class="form-control" placeholder="Número de autorización" required>
                                            <?php if ($errors->has('nro_autorizacion')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nro_autorizacion'); ?>
                                            <strong class="text-danger"><?php echo e($message); ?></strong>
                                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="">Fecha límite de emisión</label>
                                            <input type="date" name="fecha_limite" value="<?php echo e(old('fecha_limite')); ?>" class="form-control" required>
                                            <?php if ($errors->has('fecha_limite')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('fecha_limite'); ?>
                                            <strong class="text-danger"><?php echo e($message); ?></strong>
                                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-md-12">
                                            <label for="">Llave de dosificación</label>
                                            <textarea name="llave_dosificacion" class="form-control"><?php echo e(old('llave_dosificacion')); ?></textarea>
                                            <?php if ($errors->has('llave_dosificacion')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('llave_dosificacion'); ?>
                                            <strong class="text-danger"><?php echo e($message); ?></strong>
                                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-md-6">
                                            <label for="">Numero inicial</label>
                                            <input type="number" min="1" step="1" name="numero_inicial" value="<?php echo e(old('numero_inicial') ? old('numero_inicial') : 1); ?>" class="form-control" required>
                                            <?php if ($errors->has('numero_inicial')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('numero_inicial'); ?>
                                            <strong class="text-danger"><?php echo e($message); ?></strong>
                                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="">Estado</label><br>
                                            <input type="checkbox" checked disabled id="check-activa" name="estado" data-toggle="toggle" data-on="Activa" data-off="Inactiva">
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <button type="submit" class="btn btn-primary">Guardar</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('css'); ?>
        <style>

        </style>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('javascript'); ?>
        <script>
            $(document).ready(function() {

            });
        </script>
    <?php $__env->stopSection(); ?>

<?php else: ?>
    <?php $__env->startSection('content'); ?>
        <?php echo $__env->make('errors.sin_permiso', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatcom\resources\views/dosificaciones/dosificaciones_create.blade.php ENDPATH**/ ?>