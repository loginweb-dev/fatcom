<?php $__env->startSection('page_title', 'Nuevo Producto'); ?>

<?php if(auth()->user()->hasPermission('add_productos')): ?>
    <?php $__env->startSection('page_header'); ?>
        <h1 class="page-title">
            <i class="voyager-harddrive"></i> Añadir producto a inventario
        </h1>
        <a href="<?php echo e(route('depositos_view', ['id' => $deposito_id])); ?>" class="btn btn-warning btn-small">
            <i class="voyager-list"></i> <span>Volver a la lista</span>
        </a>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
        <div class="page-content">
            <form id="form" action="<?php echo e(route('depositos_store_producto')); ?>" method="post" enctype="multipart/form-data">
                <div class="page-content browse container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-bordered">
                                <?php echo csrf_field(); ?>
                                
                                <input type="hidden" name="unidad_id" value="1">
                                <input type="hidden" name="talla_id" value="1">
                                <input type="hidden" name="color_id" value="1">
                                <input type="hidden" name="genero_id" value="1">
                                <input type="hidden" name="uso_id" value="1">
                                

                                <input type="hidden" name="stock" value="0">
                                <input type="hidden" name="deposito_id" value="<?php echo e($deposito_id); ?>">
                                <input type="hidden" name="codigo_grupo" value="<?php echo e($codigo_grupo); ?>">
                                <div class="panel-body strong-panel">
                                    
                                    <div id="alerta-store" class="alert" style="display:none">
                                        <ul>
                                            <li id="mensaje-store"></li>
                                        </ul>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6" style="margin-bottom:0px">
                                            <div class="row">
                                                <div class="form-group col-md-12">
                                                    <label for="">Nombre</label>
                                                    <input type="text" name="nombre" class="form-control" placeholder="Nombre del producto" required>
                                                    <?php if ($errors->has('nombre')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nombre'); ?>
                                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-md-6">
                                                    <label for="">Código</label>
                                                    <input type="text" name="codigo_interno" class="form-control" placeholder="Código del producto" required>
                                                </div>
                                                <div class="form-group col-md-6">
                                                    <label for="">Cantidad inicial</label>
                                                    <input type="number" min="0" step="1" name="cantidad" class="form-control" required>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-md-6">
                                                    <label for="">Precio de venta</label>
                                                    <input type="number" min="1" step="0.1" name="precio_venta" class="form-control" placeholder="Precio de venta" required>
                                                    <?php if ($errors->has('precio_venta')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('precio_venta'); ?>
                                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                                <div class="form-group col-md-6">
                                                    <label for="">precio mínimo</label> <label class="text-primary" <?php if(setting('admin.tips')): ?> data-toggle="tooltip" data-placement="top" title="Este campo no necesita ser llenado" <?php endif; ?>>(Opcional)</label>
                                                    <input type="number" min="0" step="0.1" name="precio_minimo" class="form-control" placeholder="Precio mínimo de venta">
                                                    <?php if ($errors->has('precio_minimo')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('precio_minimo'); ?>
                                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-md-6">
                                                    <label for="">Moneda</label>
                                                    <select name="moneda_id" id="select-moneda_id" class="form-control select2" required>
                                                        <?php $__currentLoopData = $monedas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($item->id); ?>" ><?php echo e($item->nombre); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="form-group col-md-6">
                                                    <label for="">Sub categoría</label>
                                                    <div id="div-select_subcategorias">
                                                        <select name="subcategoria_id" id="select-subcategoria_id" class="form-control" required>
                                                            <?php $__currentLoopData = $subcategorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($item->id); ?>" ><?php echo e($item->nombre); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-md-6">
                                                    <label for="">Marca</label>
                                                    <select name="marca_id" id="select-marca_id" class="form-control" required>
                                                        <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($item->id); ?>" ><?php echo e($item->nombre); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="form-group col-md-6">
                                                    <label for="">Modelo</label>
                                                    <input type="text" name="modelo" class="form-control" placeholder="Modelo del producto" required>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-md-6">
                                                    <label for="">Garantía</label>
                                                    <input type="text" name="garantia" class="form-control" placeholder="12 meses">
                                                </div>
                                                <div class="form-group col-md-6">
                                                    <label for="">Catálogo</label>
                                                    <input type="file" name="catalogo" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6" style="margin-bottom:0px">
                                            <label for="">Imagen(s)</label>  <label class="text-primary" <?php if(setting('admin.tips')): ?> data-toggle="tooltip" data-placement="right" title="Este campo no necesita ser llenado" <?php endif; ?>>(Opcional)</label>
                                            <div class="content_uploader" style="height: 500px;">
                                                <div class="box" style="background-image:url('<?php echo e(url('storage/productos/default.png')); ?>')">
                                                    <input class="filefield" style="display:none" accept="image/*" type="file" name="imagen[]" multiple>
                                                    <p class="select_bottom">Seleccionar imagen</p>
                                                    <div class="spinner"></div>
                                                    <div class="overlay_uploader"></div>
                                                </div>
                                            </div>
                                         </div>
                                         <div class="form-group col-md-12">
                                                <label for="">Descripción</label>
                                                <textarea name="descripcion_small" class="form-control" id="" rows="3" placeholder="Descripción corta del producto" required></textarea>
                                                <?php if ($errors->has('descripcion_small')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('descripcion_small'); ?>
                                                <strong class="text-danger"><?php echo e($message); ?></strong>
                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                            </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-bordered">
                                <div class="panel-heading">
                                    <h4 class="panel-title"> Descripción para E-Commerce <label class="text-primary" style="font-size:14px" <?php if(setting('admin.tips')): ?> data-toggle="tooltip" data-placement="top" title="Este campo no necesita ser llenado" <?php endif; ?>>(Opcional)</label></h4>
                                    <div class="panel-actions">
                                        <a class="panel-action panel-collapsed voyager-angle-down" data-toggle="panel-collapse" aria-hidden="true"></a>
                                    </div>
                                </div>
                                <div class="panel-body collapse">
                                    <div class="form-group">
                                        <textarea class="form-control richTextBox" name="descripcion_long" row="3"></textarea>
                                    </div>
                                </div>
                                <div class="panel-footer">
                                    <input type="checkbox" checked id="check-clear" name="clear">
                                    <label for="check-clear">Limpiar el formulario.</label>
                                    <br><br>
                                    <button type="submit" class="btn btn-primary">Guardar</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <?php echo $__env->make('partials.modal_load', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('css'); ?>
        <link rel="stylesheet" href="<?php echo e(url('image-preview/image-preview.css')); ?>">
        <style>

        </style>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('javascript'); ?>
        <script src="<?php echo e(url('image-preview/image-preview.js')); ?>"></script>
        <script src="<?php echo e(url('js/loginweb.js')); ?>"></script>
        <script>
            $(document).ready(function(){
                $('[data-toggle="popover"]').popover({ html : true });
                $('[data-toggle="tooltip"]').tooltip();

                // inicializar select2
                inicializar_select2('subcategoria_id');
                inicializar_select2('marca_id');
                // =======================

                // *******************codigo adicional*******************
                $('#form').on('submit', function(e){
                    e.preventDefault();
                    $('#modal_load').modal('show');
                    $("html,body").animate({scrollTop: $('#alerta-store').offset().top}, 1000);

                    let formData = new FormData(document.getElementById("form"));
                    formData.append("dato", "valor");
                    $.ajax({
                        url: '<?php echo e(route("depositos_store_producto")); ?>',
                        type: 'post',
                        dataType: "html",
                        data: formData,
                        cache: false,
                        contentType: false,
                        processData: false,
                        success: function(response){
                            let data = JSON.parse(response);
                            if(data.response==1){

                                // vaciar formulario si se hizo check
                                if ($('#check-clear').prop("checked")) {
                                    $('#form').trigger("reset");
                                    $('#form input[name="codigo_grupo"]').val(data.nuevo_grupo);
                                    select2_reload('subcategoria_id', data.subcategorias, false, '');
                                    select2_reload('marca_id', data.marcas, false, '');
                                    $('.box').css('background-image', "url('<?php echo e(url('storage/productos/default.png')); ?>')");
                                }
                                // =================================

                                // mostrar y ocultar alertas
                                $('#mensaje-store').html('Producto guardado exitosamente.');
                                $('#alerta-store').css('display', 'block');
                                $('#alerta-store').addClass('alert-success');
                                setInterval(function(){
                                    $('#alerta-store').fadeOut( "slow");
                                }, 5000);
                                // ===========================
                            }else{
                                $('#mensaje-store').html('Ocurrio un error al guardar el producto');
                                $('#alerta-store').css('display', 'block');
                                $('#alerta-store').addClass('alert-danger');
                                setInterval(function(){
                                    $('#alerta-store').fadeOut( "slow");
                                }, 5000);
                            }
                            $('#modal_load').modal('hide');
                        }
                    });
                });
                // *******************/script adicional*******************
            });
        </script>
    <?php $__env->stopSection(); ?>

<?php else: ?>
    <?php $__env->startSection('content'); ?>
        <?php echo $__env->make('errors.sin_permiso', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatcom\resources\views/inventarios/depositos/electronica_computacion/depositos_create_producto.blade.php ENDPATH**/ ?>