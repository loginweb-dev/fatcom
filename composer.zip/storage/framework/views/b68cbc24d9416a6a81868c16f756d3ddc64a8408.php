<?php $__env->startSection('page_title', 'Añadir Deposito'); ?>

<?php if(auth()->user()->hasPermission('add_depositos')): ?>
    <?php $__env->startSection('page_header'); ?>
        <h1 class="page-title">
            <i class="voyager-archive"></i> Añadir Deposito
        </h1>
        
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>
        <div class="page-content">
            <div class="page-content browse container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-bordered">
                            <form action="<?php echo e(route('depositos_store')); ?>" method="post">
                                <div class="panel-body strong-panel">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group col-md-12">
                                        <label for="">Nombre</label><?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Nombre que se asigno al deposito, en caso de solo existir un deposito ingresar Deposito casa matriz. Este campo es obligatorio."></span> <?php endif; ?>
                                        <input type="text" name="nombre" class="form-control" placeholder="Nombre del almacen" required>
                                        <?php if ($errors->has('nombre')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nombre'); ?>
                                        <strong class="text-danger"><?php echo e($message); ?></strong>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                    <div class="form-group col-md-12">
                                        <label for="">Dirección</label><?php if(setting('admin.tips')): ?> <span class="voyager-question text-default pull-right" data-toggle="tooltip" data-placement="left" title="Dirección del deposito. Este campo es obligatorio."></span> <?php endif; ?>
                                        <textarea name="direccion"class="form-control" rows="5"></textarea>
                                    </div>
                                    <div class="col-md-12">
                                        <button type="submit" class="btn btn-primary">Guardar</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('css'); ?>
        <style>

        </style>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('javascript'); ?>
        <script>
            $(document).ready(function() {
                $('[data-toggle="tooltip"]').tooltip();
            });
        </script>
    <?php $__env->stopSection(); ?>

<?php else: ?>
    <?php $__env->startSection('content'); ?>
        <?php echo $__env->make('errors.sin_permiso', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatcom\resources\views/inventarios/depositos/depositos_create.blade.php ENDPATH**/ ?>