<?php
    $cont = 0;
?>
<?php $__empty_1 = true; $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php
        $precio_venta = $precios[$cont]['precio'];
        $precio_actual = $precio_venta;
        if($ofertas[$cont]['oferta']){
            if($ofertas[$cont]['oferta']->tipo_descuento=='porcentaje'){
                $precio_actual -= ($precio_actual*($ofertas[$cont]['oferta']->monto/100));
            }else{
                $precio_actual -= $ofertas[$cont]['oferta']->monto;
            }
        }
    ?>
    <article class="card card-product">
        <div class="card-body">
            <div class="row">
                <?php
                    $img = ($item->imagen!='') ? str_replace('.', '_small.', $item->imagen) : 'productos/default.png';
                ?>
                
                <aside class="col-lg-3">
                    <div class="img-wrap"><img src="<?php echo e(url('storage').'/'.$img); ?>"></div>
                </aside>
                
                <article class="col-lg-5">
                    <h4 class="title"> <?php echo e($item->nombre); ?> </h4>
                    <div class="rating-wrap">
                        <ul class="rating-stars">
                            <li style="width:<?php echo e($puntuaciones[$cont]['puntos']*20); ?>%" class="stars-active">
                                <i class="fa fa-star"></i> <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i> <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </li>
                            <li>
                                <i class="fa fa-star"></i> <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i> <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </li>
                        </ul>
                        <div class="label-rating"> <?php echo e(number_format($puntuaciones[$cont]['puntos'], 1, ',', '')); ?></div>
                        <div class="label-rating" title="Visto <?php echo e($item->vistas); ?> veces"> <span class="fa fa-eye"></span> <?php echo e($item->vistas); ?> </div>
                    </div>
                    <p> <?php echo e($item->descripcion_small); ?> </p>
                    <dl class="dlist-align">
                        <dt>Marca</dt>
                        <dd><?php echo e($item->marca); ?></dd>
                    </dl>
                    <dl class="dlist-align">
                        <dt>Modelo</dt>
                        <dd><?php echo e($item->modelo); ?></dd>
                    </dl>
                    <dl class="dlist-align">
                        <dt>Garantía</dt>
                        <dd><?php echo e($item->garantia); ?></dd>
                    </dl>
                </article>
                
                <aside class="col-lg-4 border-left">
                    <div class="action-wrap">
                        <div class="price-wrap h4">
                            <?php if(!$ofertas[$cont]['oferta']): ?>
                            <span class="price"> <?php echo e($item->moneda); ?> <?php echo e(number_format($precio_venta, 2, ',', '.')); ?> </span>
                            <?php else: ?>
                            <span class="price"> <?php echo e($item->moneda); ?> <?php echo e(number_format($precio_actual, 2, ',', '.')); ?> </span>
                            <del class="price-old"> <?php echo e($item->moneda); ?> <?php echo e(number_format($precio_venta, 2, ',', '.')); ?> </del>
                            <?php endif; ?>
                        </div>
                        
                        <br>
                        <p>
                            <button style="margin:5px" type="button" id="btn-add_carrito" class="btn btn-warning" onclick="agregar(<?php echo e($item->id); ?>)"> <i class="fa fa-shopping-cart"></i> Agregar</button>
                            <a style="margin:5px" href="<?php echo e(route('detalle_producto_ecommerce', ['producto'=>$item->slug])); ?>" class="btn btn-primary link-page"> <i class="fa fa-list"></i> Detalles  </a>
                        </p>
                        
                    </div>
                </aside>
            </div>
        </div>
    </article>
    <?php
        $cont++;
    ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="col-md-12 text-center bg-white padding-y-lg">
        <h1 class="display-4">OOPS!</h1>
        <h2 class="display-6">No se encontraron resultados.</h2>
    </div>
<?php endif; ?>
<?php if(count($productos)>0): ?>
<div class="row">
    <div id="paginador-search" class="col-md-12" style="overflow-x:auto">
        <?php echo e($productos->links()); ?>

    </div>
</div>
<?php endif; ?>

<script>
    // Paginador de busqueda
    $('.page-link').click(function(){
        let page = $(this).prop('href');
        buscar(page.split('page=')[1]);
        return false;
    });
</script>
<?php /**PATH C:\xampp\htdocs\fatcom\resources\views/ecommerce/busqueda.blade.php ENDPATH**/ ?>