<?php $__env->startSection('meta-datos'); ?>
    <title>Mis pedidos - <?php echo e(setting('admin.title')); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-md-12 text-center bg-white padding-y-lg">
        <h1 class="display-4">OOPS!</h1>
        <h2 class="display-6">No se encontraron resultados.</h2>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('ecommerce.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatcom\resources\views/ecommerce/pedidos_empty.blade.php ENDPATH**/ ?>