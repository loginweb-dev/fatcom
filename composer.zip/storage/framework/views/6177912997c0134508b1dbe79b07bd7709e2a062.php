<?php $__env->startSection('meta-datos'); ?>
    <title><?php echo e($producto->nombre); ?></title>
    <meta property="og:url"           content="<?php echo e(route('detalle_producto_ecommerce', ['producto' => $producto->slug])); ?>" />
    <meta property="og:type"          content="E-Commerce" />
    <meta property="og:title"         content="<?php echo e($producto->nombre); ?>" />
    <meta property="og:description"   content=" <?php echo e($producto->descripcion_small); ?>" />
    <meta property="og:image"         content="<?php echo e(url('storage').'/'.$producto->imagen); ?>" />

    
    <script async defer crossorigin="anonymous" src="https://connect.facebook.net/es_LA/sdk.js#xfbml=1&version=v3.3&appId=302829090588863&autoLogAppEvents=1"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('banner'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main id="contenido" class="col-md-9 col-sm-12">
        <div class="card">
            <div class="row no-gutters">
                <aside class="col-sm-6 border-right">
                    <article class="gallery-wrap">
                        <div class="img-big-wrap" style="text-align:center">

                            
                            <div id="loader-img" style="display:none;position:absolute;width:100%;height:100%;background-color:rgba(0, 0, 0, 0.7);justify-content: center;align-items: center;">
                                <img src="<?php echo e(voyager_asset('images/load.gif')); ?>" style="width:70px;height:70px" alt="loader">                                
                            </div>
                            

                            <?php
                                $img = ($producto->imagen!='') ? str_replace('.', '_medium.', $producto->imagen) : 'productos/default.png';
                                $imagen = ($producto->imagen!='') ? $producto->imagen : 'productos/default.png';
                            ?>
                            <a id="img-slider" href="<?php echo e(url('storage').'/'.$imagen); ?>" data-fancybox="slider1">
                                <img id="img-medium" class="img-thumbnail img-sm" src="<?php echo e(url('storage').'/'.$img); ?>">
                            </a>
                        </div>
                        <div class="img-small-wrap">
                            <?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $img = str_replace('.', '_small.', $item->imagen);
                                    $imagen = $item->imagen;
                                ?>
                                <div class="item-gallery"><img src="<?php echo e(url('storage').'/'.$img); ?>" class="img-thumbnail img-sm img-gallery" data-img="<?php echo e(url('storage').'/'.$img); ?>"></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </article> <!-- gallery-wrap .end// -->
                </aside>
                <aside class="col-sm-6">
                    <article class="card-body">
                    <!-- short-info-wrap -->
                        <h3 class="title mb-3"><?php echo e($producto->nombre); ?></h3>
                        <div class="mb-3">
                            <?php
                                $precio_venta = $producto->precio_venta;
                                $precio_actual = $precio_venta;
                                if($oferta){
                                    if($oferta->tipo_descuento=='porcentaje'){
                                        $precio_actual -= ($precio_actual*($oferta->monto/100));
                                    }else{
                                        $precio_actual -= $oferta->monto;
                                    }
                                }
                            ?>
                            <var class="price h3 text-warning">
                                <?php if(!$oferta): ?>
                                    <span class="currency"><?php echo e($producto->moneda); ?> </span><span class="num"><?php echo e(number_format($precio_venta, 2, ',', '.')); ?></span>
                                <?php else: ?>
                                    <span class="currency"><?php echo e($producto->moneda); ?> </span><span class="num"><?php echo e(number_format($precio_actual, 2, ',', '.')); ?></span>
                                    <del class="price-old"><?php echo e($producto->moneda); ?> <?php echo e(number_format($precio_venta, 2, ',', '.')); ?></del>
                                <?php endif; ?>
                            </var>
                            <?php if(count($precios_venta) > 1): ?>
                            <var class="price h3 text-warning">
                                <?php
                                $lista_precios = '';
                                foreach ($precios_venta as $item) {
                                    if ($item->cantidad_minima > 1) {
                                        $lista_precios .= '<h6 class="text-dark">A partir de '.$item->cantidad_minima.' a '.$item->moneda.' '.$item->precio.'</h6>';
                                    }
                                }    
                                ?>
                                <button class="btn btn-success btn-sm" data-toggle="popover" data-trigger="focus" data-html="true" title="Todos los precios" data-placement="bottom" data-content='
                                    <div class="text-center" style="width:200px">
                                        <?php echo e($lista_precios); ?>

                                    </div>'>
                                    <i class="fas fa-plus"></i> Precios
                                </button>
                            </var>
                            <?php endif; ?>
                        </div>

                        <?php if($oferta): ?>
                        <?php
                            $monto_ahorro = $precio_venta-$precio_actual;
                            $porcentaje_ahorro = round(($monto_ahorro*100)/$precio_venta, 0, PHP_ROUND_HALF_UP);
                        ?>
                        <dl class="row">
                            <dt class="col-sm-3">Ahorras</dt>
                            <dd class="col-sm-9 b text-danger"><?php echo e($producto->moneda); ?> <?php echo e(number_format($monto_ahorro, '2', ',', '.')); ?> (<?php echo e(intval($porcentaje_ahorro)); ?>%)</dd>
                            <?php if($oferta->fin!=''): ?>
                            <dt class="col-md-12 b text-info">La oferta finaliza <?php echo e(\Carbon\Carbon::parse($oferta->fin)->diffForHumans()); ?></dt>
                            <?php endif; ?>
                        </dl>
                        <?php endif; ?>
                        <dl>
                            <dt>Descripción</dt>
                            <dd><p><?php echo e($producto->descripcion_small); ?> </p></dd>
                        </dl>
                        
                        <?php if(setting('admin.modo_sistema') == 'electronica_computacion'): ?>
                        <dl class="row">
                                <dt class="col-sm-3">Marca</dt>
                                <dd class="col-sm-9"><?php echo e($producto->marca); ?></dd>
    
                                <dt class="col-sm-3">Modelo</dt>
                                <dd class="col-sm-9"><?php echo e($producto->modelo); ?></dd>
    
                                <?php if(!empty($producto->garantia)): ?>
                                <dt class="col-sm-3">Garantía</dt>
                                <dd class="col-sm-9"><?php echo e($producto->garantia); ?></dd>
                                <?php endif; ?>
    
                                <?php if(!empty($producto->catalogo)): ?>
                                <dt class="col-sm-3">Catálogo</dt>
                                <dd class="col-sm-9"><a target="_blank" class="btn btn-success btn-sm" href="<?php echo e(url('storage').'/'.$producto->catalogo); ?>">Ver <span class="fas fa-book"></span></a></dd>
                                <?php endif; ?>
                            </dl>
                        <?php endif; ?>
                        
                        <?php
                            $puntuacion = number_format($puntuacion, 1, '.', '');
                        ?>
                        <div class="rating-wrap">
                            <ul class="rating-stars">
                                <li style="width:<?php echo e($puntuacion*20); ?>%" class="stars-active">
                                    <i class="fa fa-star"></i> <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i> <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </li>
                                <li>
                                    <i class="fa fa-star"></i> <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i> <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </li>
                            </ul>
                            
                            <div class="label-rating"> <?php echo e($puntuacion); ?></div>
                            
                            <?php if((empty($habilitar_puntuar))): ?>
                                <div class="label-rating">
                                    <button class="btn btn-info btn-sm" data-toggle="popover" data-trigger="click" data-html="true" title="Calificación" data-placement="top" data-content='
                                        <div class="text-center" style="width:250px">
                                            <h6>¿Qué te parece nuestro producto?</h6>
                                            <hr>
                                            <form action="<?php echo e(route('productos_puntuar')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="id" value="<?php echo e($id); ?>">
                                                <input type="hidden" name="puntos" id="input-puntos" value="" required>
                                                <ul class="rating-stars">
                                                    <li style="width:0%" id="puntuacion" class="stars-active">
                                                        <i class="fa fa-star" onclick="puntuar(20)"></i>
                                                        <i class="fa fa-star" onclick="puntuar(40)"></i>
                                                        <i class="fa fa-star" onclick="puntuar(60)"></i>
                                                        <i class="fa fa-star" onclick="puntuar(80)"></i>
                                                        <i class="fa fa-star" onclick="puntuar(100)"></i>
                                                    </li>
                                                    <li>
                                                        <i class="fa fa-star" onclick="puntuar(20)"></i>
                                                        <i class="fa fa-star" onclick="puntuar(40)"></i>
                                                        <i class="fa fa-star" onclick="puntuar(60)"></i>
                                                        <i class="fa fa-star" onclick="puntuar(80)"></i>
                                                        <i class="fa fa-star" onclick="puntuar(100)"></i>
                                                    </li>
                                                </ul>
                                                <hr>
                                                <div class="text-right">
                                                    <button type="submit" class="btn btn-sm btn-info">Enviar</button>
                                                </div>
                                            </form>
                                        </div>'>
                                        Puntuar
                                    </button>
                                </div>
                            <?php endif; ?>
                            <div class="label-rating" title="Visto <?php echo e($producto->vistas); ?> veces"> <span class="fa fa-eye"></span> <?php echo e($producto->vistas); ?> </div>
                        </div>

                        
                        <br>
                        <div class="label-rating">
                            <?php
                                $disponible = true;
                            ?>
                            <?php if($envio): ?>
                                <?php if($envio == 'no asignado'): ?>
                                    <i>No has elegido la ciudad en la que te encuentras, por favor ingresa <a href="#"><b>aquí</b></a> para editar tu información.</i>
                                <?php elseif($envio == 'no definido'): ?>
                                    <i>El envío de este producto <b>no está</b> disponible en tu ciudad. <br>Para ver las ciudades en las que está disponible el envío de este producto presiona
                                        
                                        <?php
                                            $ciudades = '<table width="100%">';
                                            foreach ($localidades_disponibles as $item) {
                                                $precio = ($item->precio > 0) ? 'Bs. '.$item->precio : '<b><i>Gratis</i></b>';
                                                $ciudades .= '<tr><td>'.$item->ciudad.' '.$precio.'</td></tr>';
                                            }
                                            $ciudades .= '</table>';
                                        ?>
                                        <a href="#" id="btn-costo_envios"
                                            data-toggle="popover" data-trigger="focus" data-html="true" title="Ciudades disponibles" data-placement="bottom" data-content='
                                            <div style="width:250px">
                                                <?php if($ciudades != '<table width="100%"></table>'): ?> <?php echo e($ciudades); ?> <?php else: ?> <h6 class="text-center">No disponible en ninguna ciudad.</h6> <?php endif; ?>
                                            </div>'><b>Aquí</b>
                                        </a>.
                                    </i>
                                    <?php
                                        $disponible = false;
                                    ?>
                                <?php else: ?>
                                    <?php if($envio->precio == 0): ?>
                                        <i>Este producto tiene envío <b>gratis</b> para <?php echo e($envio->localidad); ?>.</i>
                                    <?php else: ?>
                                        <i>Este producto tiene un costo de envío de <b> Bs. <?php echo e($envio->precio); ?></b> para <?php echo e($envio->localidad); ?>.</i>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php else: ?>
                                <i>Debes <a href="<?php echo e(route('login')); ?>"><b>Iniciar sesión</b></a> o <a href="<?php echo e(route('register')); ?>"><b>registrarte</b></a> para averiguar el costo de envío del producto.</i>
                            <?php endif; ?>
                        </div>

                        <?php if($disponible): ?>
                        <hr>
                        <button style="margin:5px" type="button" id="btn-add_carrito" data-id="<?php echo e($id); ?>" class="btn btn-warning" onclick="agregar(<?php echo e($id); ?>)"> <i class="fa fa-shopping-cart"></i> Agregar al carrito</button>
                        <a style="margin:5px" href="<?php echo e(url('carrito/agregar/comprar').'/'.$id); ?>" class="btn  btn-outline-warning link-page"> Comprar ahora </a>
                        <?php endif; ?>
                        <hr>
                        <div class="clearfix"></div>
                        <table>
                            <tr>
                                <td>
                                    
                                    <div class="fb-like" data-href="<?php echo e(route('detalle_producto_ecommerce', ['producto' => $producto->slug])); ?>" data-width="" data-layout="button_count" data-action="like" data-size="large" data-show-faces="true" data-share="true"></div>
                                </td>
                                <td>
                                    
                                    <a style="margin-top:-1px" 
                                        <?php if($dispositivo=='pc'): ?> 
                                            href="https://api.whatsapp.com/send?phone=&text=<?php echo e(route('detalle_producto_ecommerce', ['producto' => $producto->slug])); ?>&source=&data="}}
                                        <?php else: ?> 
                                            href="whatsapp://send?text=<?php echo e(route('detalle_producto_ecommerce', ['producto' => $producto->slug])); ?>"
                                        <?php endif; ?> 
                                        title="Compartir vía WhatsApp" class="btn btn-success btn-sm" target="_blank">
                                        WhatsApp <i class="fab fa-whatsapp"></i>
                                    </a>
                                </td>
                            </tr>
                        </table>
                    </article>
                </aside>
            </div>
        </div>
        <?php if(!empty($producto->descripcion_long)): ?>
        <div class="card mb-3">
            <header class="card-header">
                <a href="#" data-toggle="collapse" data-target="#collapse11" aria-expanded="true" class="">
                    <i class="icon-action fa fa-chevron-down"></i>
                    <h5 class="title">Descripción detallada del producto</h5>
                </a>
            </header>
            <div class="" id="collapse11" style="">
                <article class="card-body">
                        <?php echo $producto->descripcion_long; ?>

                </article>
            </div>
        </div>
        <?php endif; ?>
        <div>
            <div class="card card-filter">
                <div class="fb-comments" data-href="<?php echo e(route('detalle_producto_ecommerce', ['producto' => $producto->slug])); ?>" data-width="" data-numposts="5"></div>
            </div>
        </div>
    </main>
    <aside class="col-md-3 col-sm-12">
        <div class="card card-filter">
            <div class="box" style="height:539px;overflow-y:auto">
                <h6>Productos similares</h6><br>
                <?php $__currentLoopData = $recomendaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <figure class="itemside mb-3">
                        <?php
                            $img = ($item['imagen']!='') ? str_replace('.', '_small.', $item['imagen']) : 'productos/default.png';
                        ?>
                        <div class="aside">	<img class="img-sm" width="80" src="<?php echo e(url('storage').'/'.$img); ?>"> </div>
                        <figcaption class="text-wrap">
                            <p class="title b"><?php echo e($item['nombre']); ?></p>
                            <button class="btn btn-warning btn-sm" type="button" title="Agregar al carrito de compra" onclick="agregar(<?php echo e($item['id']); ?>)"> <i class="fa fa-shopping-cart"></i> </button>
                            <a href="<?php echo e(route('detalle_producto_ecommerce', ['id'=>$item['slug']])); ?>" title="Detalles" class="btn btn-primary btn-sm link-page"> <i class="fa fa-list"></i> </a>
                        </figcaption>
                    </figure>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        
        <br>
        <div class="card card-filter">
            <div class="fb-group" data-href="https://www.facebook.com/groups/443787396385175/" data-width="280" data-show-social-context="true" data-show-metadata="false"></div>
        </div>
    </aside>

<?php $__env->stopSection(); ?>
<script src="<?php echo e(url('ecommerce/js/jquery-2.0.0.min.js')); ?>" type="text/javascript"></script>
<script>
    $(document).ready(function(){
        $('[data-toggle="popover"]').popover({ html : true });

        // cambiar imagen de muestra
        $('.img-gallery').click(function(){
            $('#loader-img').css('display', 'flex');
            let img_medium = $(this).data('img').replace('_small', '_medium');
            let img = $(this).data('img').replace('_small', '');
            $('#img-medium').attr('src', img_medium);
            $('#img-slider').attr('href', img);
            setTimeout(() => {
                $('#loader-img').css('display', 'none');
            }, 1000);
        });

        // Anular la acción predeterminada del link de costo de enviós
        $('#btn-costo_envios').click(function(e){
            e.preventDefault();
        });
    });

    function puntuar(puntos){
        $('#puntuacion').css('width', puntos+'%');
        $('#input-puntos').val(puntos);
    }
</script>

<?php echo $__env->make('ecommerce.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatcom\resources\views/ecommerce/detalle.blade.php ENDPATH**/ ?>