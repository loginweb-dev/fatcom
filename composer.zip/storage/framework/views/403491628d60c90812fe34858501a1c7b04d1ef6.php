<?php $__env->startSection('page_title', 'Registros'); ?>

<?php if(auth()->user()->hasPermission('browse_asientos')): ?>
    <?php $__env->startSection('page_header'); ?>
        <h1 class="page-title">
            <i class="voyager-dollar"></i> Registros
        </h1>
        <?php if(auth()->user()->hasPermission('add_asientos')): ?>
        <a href="<?php echo e(route('asientos_create')); ?>" class="btn btn-success btn-add-new">
            <i class="voyager-plus"></i> <span>Añadir nuevo</span>
        </a>
        <?php endif; ?>
        <?php echo $__env->make('voyager::multilingual.language-selector', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
        <div class="page-content">
            <div class="page-content browse container-fluid">

                <?php echo $__env->make('voyager::alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-bordered">
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-8"></div>
                                        <form id="form-search" class="form-search">
                                            <div class="input-group col-md-4">
                                                <input type="date" id="search_value" class="form-control" name="s" value="<?php echo e($value); ?>">
                                                <span class="input-group-btn">
                                                    <button class="btn btn-default" style="margin-top:0px;padding:5px 10px" type="submit">
                                                        <i class="voyager-search"></i>
                                                    </button>
                                                </span>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <div class="table-responsive">
                                    <table id="dataTable" class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th><a href="#"></a></th>
                                                <th><a href="#">Usuario</a></th>
                                                <th><a href="#">Tipo</a></th>
                                                <th><a href="#">Concepto</a></th>
                                                <th><a href="#">Fecha</a></th>
                                                <th><a href="#">Monto</a></th>
                                                <th class="text-right">Acciones</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php setlocale(LC_ALL, 'es_ES'); ?>
                                            <?php $__empty_1 = true; $__currentLoopData = $asientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($item->id); ?></td>
                                                <td><?php echo e($item->name); ?></td>
                                                <td><?php echo e($item->tipo); ?></td>
                                                <td><?php echo e($item->concepto); ?></td>
                                                <td><?php echo e(strftime('%d-%B-%Y %H:%M', strtotime($item->fecha.' '.$item->hora))); ?><br><small><?php echo e(\Carbon\Carbon::parse($item->fecha.' '.$item->hora)->diffForHumans()); ?></small></td>
                                                <td><?php echo e($item->monto); ?> Bs.</td>
                                                <td class="no-sort no-click text-right" id="bread-actions">
                                                    <?php if(auth()->user()->hasPermission('delete_asientos')): ?>
                                                        <?php if($item->deleted_at == null): ?>
                                                            <?php if($item->venta_id == null && $item->compra_id == null): ?>
                                                            <a href="#" <?php if(!$item->abierta): ?> onclick="mensaje_error()" <?php else: ?> data-toggle="modal" data-target="#delete_modal" data-id="<?php echo e($item->id); ?>" data-caja_id="<?php echo e($item->caja_id); ?>" data-tipo="<?php echo e($item->tipo); ?>" data-monto="<?php echo e($item->monto); ?>" <?php endif; ?> class="btn btn-danger btn-delete delete"><span class="voyager-trash"> Anular</span></a>
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                        <label class="label label-danger">Eliminado</label>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="8"><br><center><h5>No existen registros.</h5></center></td>
                                            </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="col-md-12">
                                <div class="col-md-4">
                                    <p class="text-muted">Mostrando del <?php echo e($asientos->firstItem()); ?> al <?php echo e($asientos->lastItem()); ?> de <?php echo e($asientos->total()); ?> registros.</p>
                                </div>
                                <div class="col-md-8">
                                    <nav class="text-right">
                                        <?php echo e($asientos->links()); ?>

                                    </nav>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="modal modal-danger fade" tabindex="-1" id="delete_modal" role="dialog">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                        aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title">
                                <i class="voyager-trash"></i> Estás seguro que quieres anular el registo?
                            </h4>
                        </div>
                        <div class="modal-body">
                        </div>
                        <div class="modal-footer">
                            <form action="<?php echo e(route('asientos_delete')); ?>" method="POST">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="id" value="">
                                <input type="hidden" name="caja_id" value="">
                                <input type="hidden" name="monto" value="">
                                <input type="hidden" name="tipo" value="">
                                <input type="submit" class="btn btn-danger pull-right delete-confirm"value="Sí, ¡Anular!">
                            </form>
                            <button type="button" class="btn btn-default pull-right" data-dismiss="modal">
                                Cancelar
                            </button>
                        </div>
                    </div>
                </div>
            </div>

    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('css'); ?>
        <style>
        </style>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('javascript'); ?>
        <script>
            $(document).ready(function() {
                $('#search_key').select2();

                // obtenet id de anulacion
                $('.btn-delete').click(function(){
                    $('#delete_modal input[name="id"]').val($(this).data('id'));
                    $('#delete_modal input[name="caja_id"]').val($(this).data('caja_id'));
                    $('#delete_modal input[name="monto"]').val($(this).data('monto'));
                    $('#delete_modal input[name="tipo"]').val($(this).data('tipo'));
                });
            });

            // enviar formulario de busqueda
            $('#form-search').on('submit', function(e){
                e.preventDefault();
                let value = $("#search_value").val();
                if(value==''){
                    value = 'all';
                }
                window.location = `<?php echo e(url('admin/asientos/buscar/${value}')); ?>`;
            });

            // error al eliminar un ingreso si la caja ya cerro
            function mensaje_error(){
                toastr.error('No puede anular el ingreso debido a que esta registrado a una caja que se encuentra cerrada.', 'Error');
            }
        </script>
    <?php $__env->stopSection(); ?>

<?php else: ?>
    <?php $__env->startSection('content'); ?>
        <?php echo $__env->make('errors.sin_permiso', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatcom\resources\views/cajas/asientos_index.blade.php ENDPATH**/ ?>