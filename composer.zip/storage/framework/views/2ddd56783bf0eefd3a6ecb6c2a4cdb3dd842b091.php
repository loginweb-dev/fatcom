<?php $__env->startSection('page_title', 'Ventas'); ?>

<?php if(auth()->user()->hasPermission('browse_ventas')): ?>
    <?php $__env->startSection('page_header'); ?>
        <h1 class="page-title">
            <i class="voyager-basket"></i> Ventas
        </h1>
        <?php if(auth()->user()->hasPermission('add_ventas')): ?>
        <a href="<?php echo e(route('ventas_create')); ?>" class="btn btn-success btn-add-new">
            <i class="voyager-plus"></i> <span>Añadir nueva</span>
        </a>
        <?php endif; ?>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>
        <div class="page-content">
            <div class="page-content browse container-fluid">
                <?php echo $__env->make('voyager::alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-bordered">
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-8"></div>
                                        <form id="form-search" class="form-search">
                                            <div class="input-group col-md-4">
                                                <input type="text" id="search_value" class="form-control" name="s" value="<?php echo e($value); ?>" placeholder="Cliente, tipo o estado">
                                                <span class="input-group-btn">
                                                    <button class="btn btn-default" style="margin-top:0px;padding:5px 10px" type="submit">
                                                        <i class="voyager-search"></i>
                                                    </button>
                                                </span>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <div class="table-responsive">
                                    <table id="dataTable" class="table table-bordered table-hover">
                                        <thead>
                                            <tr>
                                                <th>N&deg; venta</th>
                                                <th>N&deg; ticket</th>
                                                <th>Tipo</th>
                                                <th>Fecha</th>
                                                <th>Cliente</th>
                                                <th>Total</th>
                                                <th>Estado</th>
                                                <th>Opción</th>
                                                <th class="actions text-right">Acciones</th>
                                            </tr>
                                        </thead>
                                        <tbody id="lista-ventas">
                                            <?php
                                                $cont = 0;
                                            ?>
                                            <?php $__empty_1 = true; $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr>
                                                    <td><?php echo e($item->id); ?></td>
                                                    <td>#<?php echo e($item->nro_venta); ?></td>
                                                    <td><ins class="text-<?php echo e($item->tipo_etiqueta); ?>" style="font-weight:bold"><?php echo e($item->tipo_nombre); ?></ins></td>
                                                    <td><?php echo e(date('d-m-Y H:i', strtotime($item->created_at))); ?> <br> <small><?php echo e(\Carbon\Carbon::parse($item->created_at)->diffForHumans()); ?></small> </td>
                                                    <td><?php echo e($item->cliente); ?></td>
                                                    <td><?php echo e($item->importe_base); ?></td>
                                                    
                                                    <?php
                                                        $debe = false;
                                                        $deuda = '';
                                                        if($item->importe_base > $item->monto_recibido){
                                                            $debe = true;
                                                            $deuda = number_format($item->importe_base - $item->monto_recibido, 2, ',', '');
                                                        }
                                                    ?>
                                                    
                                                    <td>
                                                        <?php if($item->estado == 'A'): ?>
                                                            <label class="label label-danger">Anulada</label>
                                                        <?php else: ?>
                                                            <label class="label label-<?php echo e($item->estado_etiqueta); ?>"><?php echo e($item->estado_nombre); ?></label>
                                                            
                                                            <?php if($debe && $item->estado_id == 3): ?> <label class="label label-danger" data-toggle="tooltip" data-placement="bottom" title="El cliente tiene una deuda de <?php echo e($deuda); ?> Bs.">Debe Bs. <?php echo e($deuda); ?></label><?php endif; ?>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($item->estado == 'V'): ?>
                                                            <?php if($siguiente_estado[$cont]): ?>
                                                                <a  title="<?php echo e($siguiente_estado[$cont]->nombre); ?>" class="btn btn-cambiar_estado btn-delivery btn-<?php echo e($siguiente_estado[$cont]->etiqueta); ?>"
                                                                    <?php if($siguiente_estado[$cont]->id == 4): ?>
                                                                        href="#" data-toggle="modal" data-target="#modal_delivery" data-id="<?php echo e($item->id); ?>"
                                                                    <?php else: ?>
                                                                    href="<?php echo e(route('estado_update', ['id' => $item->id, 'valor' => $siguiente_estado[$cont]->id])); ?>"
                                                                    <?php endif; ?>
                                                                >
                                                                    <i class="<?php echo e($siguiente_estado[$cont]->icono); ?>"></i> <span class="hidden-xs hidden-sm"><?php echo e($siguiente_estado[$cont]->nombre); ?></span>
                                                                </a>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="no-sort no-click text-right" id="bread-actions">
                                                        <?php if(auth()->user()->hasPermission('read_ventas')): ?>
                                                        <a href="<?php echo e(route('ventas_view', ['id' => $item->id])); ?>" title="Ver" class="btn btn-sm btn-warning view">
                                                            <i class="voyager-eye"></i> <span class="hidden-xs hidden-sm">Ver</span>
                                                        </a>

                                                            <?php if($item->estado == 'V'): ?>
                                                            <a title="Imprimir" data-id="<?php echo e($item->id); ?>" class="btn btn-sm btn-primary btn-print">
                                                                <i class="voyager-polaroid"></i> <span class="hidden-xs hidden-sm">Imprimir</span>
                                                            </a>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                        <?php if(auth()->user()->hasPermission('delete_ventas') && $item->estado == 'V'): ?>
                                                        <a href="#" title="Borrar" class="btn btn-sm btn-danger btn-delete" data-id="<?php echo e($item->id); ?>" data-importe="<?php echo e($item->importe_base); ?>" data-caja_id="<?php echo e($item->caja_id); ?>" data-toggle="modal" data-target="#modal_delete">
                                                            <i class="voyager-trash"></i> <span class="hidden-xs hidden-sm">Borrar</span>
                                                        </a>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                                <?php
                                                    $cont++;
                                                ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="8"><p class="text-center"><br>No hay registros para mostrar.</p></td>
                                            </tr>
                                        <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="col-md-12">
                                    <div class="col-md-6" style="overflow-x:auto">
                                        <?php if(count($registros)>0): ?>
                                            <p class="text-muted">Mostrando del <?php echo e($registros->firstItem()); ?> al <?php echo e($registros->lastItem()); ?> de <?php echo e($registros->total()); ?> registros.</p>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md-6" style="overflow-x:auto">
                                        <nav class="text-right">
                                            <?php echo e($registros->links()); ?>

                                        </nav>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <form action="<?php echo e(route('venta_delete')); ?>" method="POST">
            <div class="modal modal-danger fade" tabindex="-1" id="modal_delete" role="dialog">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                        aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title">
                                <i class="voyager-trash"></i> Estás seguro que quieres anular la venta?
                            </h4>
                        </div>
                        <form action="" method="POST">
                        <div class="modal-body">
                            <p>Si anula una venta ya no podra cambiar el estado de la misma.</p>
                            <select name="tipo" style="display:none" class="form-control" id="">
                                <option value="A">Anulada</option>
                                <option value="V">Valida</option>
                                <option value="E">Extraviada</option>
                                <option value="N">No autorizada</option>
                                <option value="C">Emitida en contingencia</option>
                            </select>
                        </div>
                        <div class="modal-footer">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="id" value="">
                            <input type="hidden" name="importe" value="">
                            <input type="hidden" name="caja_id" value="">
                            <input type="submit" class="btn btn-danger pull-right delete-confirm"value="Sí, borrar!">
                            <button type="button" class="btn btn-default pull-right" data-dismiss="modal">
                                Cancelar
                            </button>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </form>

        
        <form action="<?php echo e(route('asignar_repartidor')); ?>" method="POST">
            <div class="modal modal-info fade" tabindex="-1" id="modal_delivery" role="dialog">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                        aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title">
                                <i class="voyager-truck"></i> Elija al repartidor
                            </h4>
                        </div>
                        <div class="modal-body">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="id" value="">
                            <select name="repartidor_id" class="form-control select2" id="select-repartidor_id" required>
                                <option value="">--Seleccione al repartidor--</option>
                                <?php $__currentLoopData = $delivery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->nombre); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="modal-footer">
                            <input type="submit" class="btn btn-primary pull-right delete-confirm"value="Sí, elegir!">
                            <button type="button" class="btn btn-default pull-right" data-dismiss="modal">Cancelar</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>

        
        <audio id="alert" src="<?php echo e(url('audio/alert.mp3')); ?>" preload="auto"></audio>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('css'); ?>
        <style>
            .select2{
                border: 1px solid #ddd
            }
            .btn-cambiar_estado{
                padding: 3px 10px
            }
        </style>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('javascript'); ?>
        <script>
            let ultima_venta = <?php echo e($ultima_venta); ?>;
            $(document).ready(function() {
                $('[data-toggle="tooltip"]').tooltip();
                // set valor de delete
                $('.btn-delete').click(function(){
                    $('#modal_delete input[name="id"]').val($(this).data('id'));
                    $('#modal_delete input[name="importe"]').val($(this).data('importe'));
                    $('#modal_delete input[name="caja_id"]').val($(this).data('caja_id'));
                });

                // Set valor de asignar repartidor
                $('.btn-delivery').click(function(){
                    $('#modal_delivery input[name="id"]').val($(this).data('id'));
                });

                // enviar formulario de busqueda
                $('#form-search').on('submit', function(e){
                    e.preventDefault();
                    let value = (escape($('#search_value').val())!='') ? escape($('#search_value').val()) : 'all';
                    window.location = '<?php echo e(url("admin/ventas/buscar")); ?>/'+value;
                });

                // Reimprimir factura/recibo
                $('.btn-print').click(function(){
                    let id = $(this).data('id');
                    <?php if($tamanio=='rollo'): ?>
                        $.get("<?php echo e(url('admin/venta/impresion/rollo')); ?>/"+id, function(){});
                    <?php else: ?>
                        window.open("<?php echo e(url('admin/venta/impresion/normal')); ?>/"+id, "Factura", `width=700, height=400`)
                    <?php endif; ?>
                });

                setInterval(function(){
                    get_nuevo_pedido();
                }, 5000);

            });

            function get_nuevo_pedido(){
                $.get("<?php echo e(url('admin/ventas/lista_nuevos_pedidos')); ?>/"+ultima_venta, function(data){
                    if(data.length>0){
                        ultima_venta = data[0].id
                        data.forEach(item => {
                            // Parametros
                            let fecha = new Date(item.fecha).toLocaleDateString();
                            let estado_etiqueta = item.estado_etiqueta;
                            let estado_nombre = item.estado_nombre;
                            let url_estado = "<?php echo e(url('admin/ventas/update/estado')); ?>/"+item.id+"/2";
                            let url_ver = "<?php echo e(url('admin/ventas/ver')); ?>/"+item.id;

                            $('#lista-ventas').prepend(`
                                <tr>
                                    <td>#${item.id}</td>
                                    <td><ins class="text-danger" style="font-weight:bold">Pedido</ins></td>
                                    <td>${fecha} <br> <small>Hace unos segundos</small></td>
                                    <td>${item.cliente}</td>
                                    <td>${item.importe_base}</td>
                                    <td><label class="label label-${estado_etiqueta}">${estado_nombre}</label></td></td>
                                    <td>
                                        <a title="En preparación" class="btn btn-cambiar_estado btn-info" href="${url_estado}">
                                            <i class="voyager-alarm-clock"></i> <span class="hidden-xs hidden-sm">En preparación</span>
                                        </a>
                                    </td>
                                    <td class="no-sort no-click text-right" id="bread-actions">
                                        <a href="${url_ver}" title="Ver" class="btn btn-sm btn-warning view">
                                            <i class="voyager-eye"></i> <span class="hidden-xs hidden-sm">Ver</span>
                                        </a>
                                    </td>
                                    <tr>
                                </tr>
                            `);
                        });
                        toastr.info('Se han realizado nuevos pedidos.', 'Información');
                        $('#alert')[0].play();
                    }
                });
            }
        </script>
    <?php $__env->stopSection(); ?>

<?php else: ?>
    <?php $__env->startSection('content'); ?>
        <?php echo $__env->make('errors.sin_permiso', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatcom\resources\views/ventas/ventas_index.blade.php ENDPATH**/ ?>