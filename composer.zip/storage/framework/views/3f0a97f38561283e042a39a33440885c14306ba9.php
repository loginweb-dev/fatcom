<?php $__env->startSection('page_title', 'Editar producto del E-Commerce'); ?>

<?php if(auth()->user()->hasPermission('edit_ecommerce')): ?>
    <?php $__env->startSection('page_header'); ?>
        <h1 class="page-title">
            <i class="voyager-basket"></i> Editar producto
        </h1>
        
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
        <div class="page-content">
            <form name="form" action="<?php echo e(route('ecommerce_update')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($ecommerce->id); ?>">
                <input type="hidden" name="producto_id" value="<?php echo e($ecommerce->producto_id); ?>">
                <div class="page-content browse container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-bordered">
                                <div class="panel-body" style="padding-top:0px">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <label for="">Producto</label> <?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Producto que se agregará al E-Commerce. Este campo es obligatorio."></span> <?php endif; ?>
                                            <h4><?php echo e($ecommerce->nombre); ?></h4>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="input-group">
                                                <input type="text" id="input-tags" data-role="tagsinput" class="form-control" name="tags" value="<?php echo e($ecommerce->tags); ?>" placeholder="Etiquetas">
                                                <span class="input-group-addon" style="margin-top:0px;padding:7px">
                                                    <?php if(setting('admin.tips')): ?> <span class="voyager-question text-default" data-toggle="tooltip" data-placement="left" title="Palabras claves que asociarán el producto con otros para hacer recomendaciones a la hora de buscar en el E-Commerce. Este campo no es obligatorio."></span> <?php endif; ?>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <hr>
                                    <h4>Costos de envío <?php if(setting('admin.tips')): ?> <span style="font-size:15px" class="voyager-question text-default" data-toggle="tooltip" data-placement="right" title="Costos de envío del producto a las diferentes localidades, si el producto no se envía a esa localidad dejar el campo vacío y si el envío es gratis ingresar 0. Este campo no es obligatorio."></span> <?php endif; ?></h4>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="table-responsive">
                                                <table class="table table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <th>Departamento</th>
                                                            <th>Localidad</th>
                                                            <th style="width:200px">Precio</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $localidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <?php
                                                            $costo = '';
                                                            foreach ($envios as $envio) {
                                                                if($envio->localidad_id == $item->id){
                                                                    $costo = $envio->precio;
                                                                }
                                                            }
                                                        ?>

                                                        <tr>
                                                            <td>
                                                                <?php echo e($item->departamento); ?>

                                                                <input type="hidden" name="localidad_id[]" value="<?php echo e($item->id); ?>" class="form-control">
                                                            </td>
                                                            <td><?php echo e($item->localidad); ?></td>
                                                            <td>
                                                                <div class="input-group">
                                                                    <input type="number" name="precio[]" value="<?php echo e($costo); ?>" class="form-control">
                                                                    <span class="input-group-addon" style="margin-top:0px;padding:7px">Bs.</span>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel-footer">
                                    <button type="button" id="btn-submit" class="btn btn-primary">Guardar</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <?php echo $__env->make('partials.modal_load', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('css'); ?>
        <link rel="stylesheet" href="<?php echo e(url('input-multiple/bootstrap-tagsinput.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(url('input-multiple/app.css')); ?>">
        <style>
            .popover{
                width: 300px;
            }
        </style>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('javascript'); ?>
        <script src="<?php echo e(url('image-preview/image-preview.js')); ?>"></script>
        <script src="<?php echo e(url('input-multiple/bootstrap-tagsinput.js')); ?>"></script>
        <script src="<?php echo e(url('input-multiple/app.js')); ?>"></script>
        <script src="<?php echo e(url('js/loginweb.js')); ?>"></script>
        <script>
            $(document).ready(function(){
                $('[data-toggle="popover"]').popover({ html : true });
                $('[data-toggle="tooltip"]').tooltip();
                $('#input-tags').tagsinput({});

                $('#btn-submit').click(function(){
                    document.form.submit();
                });
            });
        </script>
    <?php $__env->stopSection(); ?>

<?php else: ?>
    <?php $__env->startSection('content'); ?>
        <?php echo $__env->make('errors.sin_permiso', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatcom\resources\views/inventarios/ecommerce/ecommerce_edit.blade.php ENDPATH**/ ?>