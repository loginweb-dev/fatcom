<?php $__env->startSection('meta-datos'); ?>
    <title><?php echo e(setting('admin.title')); ?></title>
    <meta property="og:url"           content="<?php echo e(url('')); ?>" />
    <meta property="og:type"          content="E-Commerce" />
    <meta property="og:title"         content="<?php echo e(setting('admin.title')); ?>" />
    <meta property="og:description"   content="<?php echo e(setting('admin.description')); ?>" />
    <meta property="og:image"         content="<?php echo e(url('storage').'/'.str_replace('\\', '/', setting('admin.social_image'))); ?>" />

    <meta name="description" content="<?php echo e(setting('admin.description')); ?>">
    <meta name="keywords" content="ecommerce, e-commerce, loginweb, ventas, internet, trinidad, beni, tecnología">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('banner'); ?>
    <section class="section-intro bg-img padding-y-lg">
        <div class="row">
            <div class="col-sm-6 mx-auto">
                <article class="white text-center mb-6">
                    <h1 class="display-2"><?php echo e(setting('admin.title')); ?></h1>
                    <p class="display-5"><?php echo e(setting('admin.description')); ?></p>
                </article>
            </div>
        </div>
        <div style="margin-bottom:-40px;margin-right:100px" class="text-right">
            <div class="fb-like" data-href="<?php echo e(url('')); ?>" data-width="" data-layout="button_count" data-action="like" data-size="large" data-show-faces="true" data-share="true"></div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <aside class="col-lg-3 col-md-5 col-sm-12">
        <div class="card card-filter">
            <article class="card-group-item">
                <header class="card-header">
                    <a class="" aria-expanded="true" href="#" data-toggle="collapse" data-target="#collapse22">
                        <i class="icon-action fa fa-chevron-down"></i>
                        <h6 class="title">Por Categoría</h6>
                    </a>
                </header>
                <div class="filter-content collapse show panel-aside" id="collapse22">
                    <div class="card-body">
                        <div id="accordion">
                            <ul class="list-unstyled list-lg">
                                <?php
                                    $cont = 0;
                                ?>
                                <li class="list-item-title text-secondary btn-search" data-tipo="subcategoria" data-id="" style="margin-bottom:0px" aria-expanded="true">Todas</li>
                                <?php $__empty_1 = true; $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <li class="list-item-title text-secondary" style="margin-bottom:0px" id="heading<?php echo e($item->id); ?>" data-toggle="collapse" data-target="#collapse<?php echo e($item->id); ?>" aria-expanded="true" aria-controls="collapse<?php echo e($item->id); ?>">
                                        <?php echo e($item->nombre); ?>

                                    </li>
                                    <div id="collapse<?php echo e($item->id); ?>" class="collapse sublist-body" aria-labelledby="heading<?php echo e($item->id); ?>" data-parent="#accordion">
                                        <ul class="list-unstyled list-lg sublist">
                                            <?php $__currentLoopData = $subcategorias[$cont]['subcategoria']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a href="#" class="btn-search" data-tipo="subcategoria" data-id="<?php echo e($item2->id); ?>" > <?php echo e($item2->nombre); ?> <span class="float-right badge badge-secondary round"></span></a></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                    <?php
                                        $cont++;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </article>
            <article class="card-group-item">
                <header class="card-header">
                    <a class="" aria-expanded="true" href="#" data-toggle="collapse" data-target="#collapse33">
                        <i class="icon-action fa fa-chevron-down"></i>
                        <h6 class="title">Rango de precios</h6>
                    </a>
                </header>
                <div class="filter-content collapse show" id="collapse33">
                    <div class="card-body">
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label>Min</label>
                                <input class="form-control input-price" id="input-min" placeholder="$0" type="number" min="0" step="1">
                            </div>
                            <div class="form-group text-right col-md-6">
                                <label>Max</label>
                                <input class="form-control input-price" id="input-max" placeholder="$1.0000" type="number" min="0" step="1">
                            </div>
                        </div>
                        <button id="btn-price" class="btn btn-block btn-outline-primary">Aplicar</button>
                    </div>
                </div>
            </article>
            <article class="card-group-item" style="display:none">
                <header class="card-header">
                    <a href="#" data-toggle="collapse" data-target="#collapse44">
                        <i class="icon-action fa fa-chevron-down"></i>
                        <h6 class="title">Por Marca </h6>
                    </a>
                </header>
                <div class="filter-content collapse show panel-aside" id="collapse44">
                    <div class="card-body">
                        <div class="custom-control custom-radio" style="margin:5px 0px">
                            <input type="radio" checked name="marca" id="option" class="custom-control-input btn-search" data-tipo="marca" data-id="">
                            <label class="custom-control-label" for="option">Todas</label>
                        </div>
                        <?php $__empty_1 = true; $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="custom-control custom-radio" style="margin:5px 0px">
                            <input type="radio" name="marca" id="option<?php echo e($item->id); ?>" class="custom-control-input btn-search" data-tipo="marca" data-id="<?php echo e($item->id); ?>">
                            <label class="custom-control-label" for="option<?php echo e($item->id); ?>"><?php echo e($item->nombre); ?></label>
                            <span class="float-right badge badge-secondary round"><?php echo e($item->productos); ?></span>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <?php endif; ?>
                    </div>
                </div>
            </article>
        </div>
    </aside>

    <main id="contenido" class="col-lg-9 col-md-7 col-sm-12" style="margin-bottom:70px">
        <?php if(count($ofertas)>0): ?>
            <?php
                $cantidad = count($ofertas)<4 ? count($ofertas) : 4;
                $size_image = count($ofertas)>=2 ? '_small.' : '_medium.';
            ?>
            <br>
            <h4 class="display-6">Ofertas <small> <a href="<?php echo e(route('ofertas_ecommerce')); ?>" class="link-page">(Ver más)</a></small> </h4><br>
            <!-- ============== slick slide items  ============= -->
            <div class="owl-carousel owl-init slide-items" data-items="<?php echo e($cantidad); ?>" data-margin="20" data-dots="false" data-nav="false">
                <?php
                    $cont = 0;
                ?>
                <?php $__currentLoopData = $ofertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $imagen = ($item->imagen!='') ? str_replace('.', $size_image, $item->imagen) : 'productos/default.png';
                    ?>
                    <div class="item-slide">
                        <figure class="card card-product">
                            <?php if(!empty($item->nuevo)): ?>
                            <span class="badge-new bg-info"> Nuevo </span>
                            <?php endif; ?>
                            <span class="badge-offer"><b>-<?php echo e($item->descuento); ?><?php if($item->tipo_descuento=='porcentaje'): ?>%<?php else: ?> <?php echo e($item->moneda); ?><?php endif; ?></b></span>
                            <div class="card-banner card-producto" style="background: url('<?php echo e(url('storage').'/'.$imagen); ?>') center;background-size:cover">
                                <article class="overlay bottom text-center">
                                    <h6 class="card-title"><?php echo e($item->nombre); ?></h6>
                                    <a href="<?php echo e(route('detalle_producto_ecommerce', ['producto'=>$item->slug])); ?>" class="btn btn-warning btn-sm link-page"> Ver detalles </a>
                                </article>
                            </div>
                        </figure>
                    </div>
                    <?php
                        $cont++;
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <!-- ============== slick slide items .end // ============= -->
        <hr>
        <?php
            $cont = 0;
        ?>
        <?php $__empty_1 = true; $__currentLoopData = $subcategoria_productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <h4 class="display-6"><?php echo e($item->nombre); ?> <small> <a href="<?php echo e(route('subcategorias_ecommerce', ['subcategoria'=>$item->slug])); ?>" class="link-page">(Ver más)</a></small> </h4><br>
            <!-- ============== slick slide items  ============= -->
            <?php
                $cantidad = count($productos_categoria[$cont])<4 ? count($productos_categoria[$cont]) : 4;
            ?>
            <div class="owl-carousel owl-init slide-items" data-items="<?php echo e($cantidad); ?>" data-margin="20" data-dots="false" data-nav="false">
                <?php $__empty_2 = true; $__currentLoopData = $productos_categoria[$cont]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                    <?php
                        $img = ($item2->imagen!='') ? str_replace('.', '_medium.', $item2->imagen) : 'productos/default.png';
                    ?>
                    <div class="item-slide">
                        <figure class="card card-product">
                            <?php if(!empty($item2->nuevo)): ?>
                            <span class="badge-new bg-info"> Nuevo </span>
                            <?php endif; ?>
                            <div class="card-banner card-producto" style="background: url('<?php echo e(url('storage').'/'.$img); ?>') center;background-size:cover">
                                <article class="overlay bottom text-center">
                                    <h6 class="card-title"><?php echo e($item2->nombre); ?></h6>
                                    <a href="<?php echo e(route('detalle_producto_ecommerce', ['producto'=>$item2->slug])); ?>" class="btn btn-warning btn-sm link-page"> Ver detalles </a>
                                </article>
                            </div>
                        </figure>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                    <div class="col-md-12 text-center bg-white padding-y-lg">
                        <h1 class="display-4">OOPS!</h1>
                        <h2 class="display-6">No se encontraron resultados.</h2>
                    </div>
                <?php endif; ?>
            </div>
            <?php
                $cont++;
            ?>
            <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-md-12 text-center bg-white padding-y-lg">
                <h1 class="display-4">OOPS!</h1>
                <h2 class="display-6">No se encontraron resultados.</h2>
            </div>
        <?php endif; ?>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('ecommerce.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatcom\resources\views/ecommerce/restaurante/index.blade.php ENDPATH**/ ?>