<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="<?php echo e(url('storage').'/'.setting('empresa.logo')); ?>" type="image/x-icon">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <?php echo $__env->yieldContent('nombre_pagina'); ?>

    <!-- Scripts -->
    

    <!-- jQuery -->
    
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">

    <!-- Font awesome 5 -->
    <link href="<?php echo e(url('ecommerce/fonts/fontawesome/css/fontawesome-all.min.css')); ?>" type="text/css" rel="stylesheet">

    
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.8/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.8/js/select2.min.js"></script>

    <!-- custom style -->
    <link href="<?php echo e(url('ecommerce/css/ui.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(url('ecommerce/css/responsive.css')); ?>" rel="stylesheet" media="only screen and (max-width: 1200px)" />

    <!-- custom javascript -->
    <script src="<?php echo e(url('ecommerce/js/script.js')); ?>" type="text/javascript"></script>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    
    <link rel="stylesheet" href="<?php echo e(url('ecommerce/css/toastr.min.css')); ?>">
    <script src="<?php echo e(url('ecommerce/js/toastr.min.js')); ?>" type="text/javascript"></script>

    <script>
        $(document).ready(function() {
        <?php if(session('alerta')): ?>
            <?php switch(session('alerta')):
                case ('cliente_editado'): ?>
                    toastr.success('Información actualizada exitosamente.', 'Bien hecho!');
                    <?php break; ?>

                <?php default: ?>

            <?php endswitch; ?>
        <?php endif; ?>
        });
    </script>
</head>
<body>
    <div id="app">
        <?php echo $__env->make('ecommerce.layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>
<?php echo $__env->yieldContent('css'); ?>
<?php echo $__env->yieldContent('script'); ?>
</html>
<?php /**PATH C:\xampp\htdocs\fatcom\resources\views/layouts/app.blade.php ENDPATH**/ ?>