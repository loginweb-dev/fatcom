<?php $__env->startSection('meta-datos'); ?>
    <title>Carrito de compra - <?php echo e(setting('admin.title')); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('banner'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <main class="col-md-12">
            <div class="card text-white bg-success col-md-6 offset-md-3">
                <div class="card-body">
                    <h3 class="text-center card-title">Muchas gracias!!!</h3>
                    <p class="card-text text-center">Puede pasar por nuestra tienda cuando desee para recoger su compra.</p>
                </div>
            </div>
            <br>
            <div class="col-md-8 offset-md-2">
                
            </div>
        </main>
<?php $__env->stopSection(); ?>
<script>
    setTimeout(function(){
        window.location = "<?php echo e(url('')); ?>";
    }, 5000);
</script>


<?php echo $__env->make('ecommerce.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatcom\resources\views/ecommerce/agradecimiento.blade.php ENDPATH**/ ?>