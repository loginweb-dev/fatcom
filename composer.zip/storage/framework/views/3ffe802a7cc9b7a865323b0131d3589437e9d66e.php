<?php $__env->startSection('page_title', 'Añadir Ingreso'); ?>

<?php if(auth()->user()->hasPermission('add_asientos')): ?>
    <?php $__env->startSection('page_header'); ?>
        <h1 class="page-title">
            Añadir Registro
        </h1>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
        <div class="page-content">
            <div class="page-content browse container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <form action="<?php echo e(route('asientos_store')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="panel panel-bordered">
                                <div class="panel-body">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Caja</label><?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Caja a la que pertenece el registro. Este campo es obligatorio."></span> <?php endif; ?>
                                            <select name="caja_id" class="form-control select2" id="" required>
                                                <?php $__currentLoopData = $cajas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->sucursal); ?> - <?php echo e($item->nombre); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="row">
                                            <div class="form-group col-md-6">
                                                <label>Tipo</label><?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Tipo de registro. Este campo es obligatorio."></span> <?php endif; ?>
                                                <select name="tipo" class="form-control select2" id="" required>
                                                    <option value="ingreso">Ingreso</option>
                                                    <option value="egreso">Egreso</option>
                                                </select>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Monto</label><?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Monto de dinero que se ingresará o retirará de la caja. Este campo es obligatorio."></span> <?php endif; ?>
                                                <input type="number" class="form-control" name="monto" required>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="form-group col-md-6">
                                                <label>Fecha</label><?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Fecha del registro. Este campo es obligatorio."></span> <?php endif; ?>
                                                <input type="date" class="form-control" name="fecha" value="<?php echo e(date('Y-m-d')); ?>" required>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Hora</label><?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Hora del registro. Este campo es obligatorio."></span> <?php endif; ?>
                                                <input type="time" class="form-control" name="hora" value="<?php echo e(date('H:i')); ?>" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Concepto</label><?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Descripción detallada del registro. Este campo es obligatorio."></span> <?php endif; ?>
                                            <textarea class="form-control" name="concepto" required rows="5"></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel-footer">
                                    <button type="submit" class="btn btn-primary save">Guardar</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('css'); ?>
        <style>
            .btn-option{
                padding: 0px;
                text-decoration: none;
            }
        </style>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('javascript'); ?>
        <script>
            $(document).ready(function(){
                $('[data-toggle="tooltip"]').tooltip();
            });
        </script>
    <?php $__env->stopSection(); ?>

<?php else: ?>
    <?php $__env->startSection('content'); ?>
        <?php echo $__env->make('errors.sin_permiso', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatcom\resources\views/cajas/asientos_create.blade.php ENDPATH**/ ?>