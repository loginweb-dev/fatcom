<?php $__env->startSection('page_title', 'Añadir Producto'); ?>

<?php if(auth()->user()->hasPermission('add_productos')): ?>
    <?php $__env->startSection('page_header'); ?>
        <h1 class="page-title">
            <i class="voyager-harddrive"></i> Añadir producto
        </h1>
        
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
        <div class="page-content">
            <form id="form" action="<?php echo e(route('productos_store')); ?>" method="post" enctype="multipart/form-data">
                <div class="page-content browse container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-bordered">
                                <?php echo csrf_field(); ?>
                                
                                <input type="hidden" name="unidad_id" value="1">
                                <input type="hidden" name="talla_id" value="1">
                                <input type="hidden" name="color_id" value="1">
                                <input type="hidden" name="genero_id" value="1">
                                <input type="hidden" name="uso_id" value="1">
                                <input type="hidden" name="moneda_id" value="2">
                                <input type="hidden" name="codigo_interno" value="">
                                <input type="hidden" name="marca_id" value="1">
                                <input type="hidden" name="precio_minimo[]" value="0">
                                <input type="hidden" name="cantidad_minima_venta[]" value="1">
                                
                                <input type="hidden" name="deposito_id" value="<?php echo e($depositos->id); ?>">
                                <input type="hidden" name="codigo_grupo" value="<?php echo e($codigo_grupo); ?>">
                                <div class="panel-body strong-panel">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="form-group col-md-12">
                                                    <label for="">Nombre comercial</label> <?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Nombre comercial del producto. Este campo es obligatorio."></span> <?php endif; ?>
                                                    <input type="text" name="nombre" class="form-control" value="<?php echo e(old('nombre')); ?>" placeholder="Nombre del producto" required>
                                                    <?php if ($errors->has('nombre')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nombre'); ?>
                                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                    <div  style="position:absolute;right:15px;top:27px">
                                                        <input type="checkbox" name="nuevo" data-toggle="toggle" data-on="Nuevo <span class='voyager-check'></span>" data-off="Nuevo <span class='voyager-x'></span>">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-md-6">
                                                    <label for="">Categoría</label> <?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Categoría a la que pertenece el producto, en caso de no existir ninguna puede crearla escribiendo el nombre y presionando la tecla ENTER. Este campo es obligatorio."></span> <?php endif; ?>
                                                    <select name="categoria_id" id="select-categoria_id" class="form-control" required>
                                                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($item->id); ?>" ><?php echo e($item->nombre); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="form-group col-md-6">
                                                    <label for="">Sub categoría</label> <?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Sub categoría del producto. las subcategorías se despliegan en base a la categoría seleccionada previamente, en caso de no existir ninguna puede crearla escribiendo el nombre y presionando la tecla ENTER. Este campo es obligatorio."></span> <?php endif; ?>
                                                    <div id="div-select_subcategorias">
                                                        <select name="subcategoria_id" id="select-subcategoria_id" class="form-control" required>
                                                            <?php $__currentLoopData = $subcategorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($item->id); ?>" ><?php echo e($item->nombre); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-md-6">
                                                    <label for="">Precio de venta</label> <?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Precio de venta del producto. Este campo es obligatorio."></span> <?php endif; ?>
                                                    <div class="input-group">
                                                        <input type="number" name="precio_venta[]" class="form-control" value="<?php echo e(old('precio_venta')); ?>" min="1" step="0.1" required>
                                                        <span class="input-group-addon">Bs.</span>
                                                    </div>
                                                    <?php if ($errors->has('precio_venta')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('precio_venta'); ?>
                                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                                <div class="form-group col-md-6">
                                                    <label for="">Cantidad</label> <?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Cantidad de productos en stock. Este campo es obligatorio."></span> <?php endif; ?>
                                                    <input type="number" name="stock" class="form-control" value="<?php echo e(old('stock') ? old('stock') : 0); ?>" min="0" step="1" required>
                                                    <div  style="position:absolute;right:15px;top:27px">
                                                        <input type="checkbox" name="se_almacena" data-toggle="toggle" data-on="<small>Se almacena</small> <span class='voyager-check'></span>" data-off="<small>Se almacena</small> <span class='voyager-x'></span>">
                                                    </div>
                                                    <?php if ($errors->has('stock')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('stock'); ?>
                                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-md-12">
                                                    <label for="" id="label-descripcion">Descripción (0/255)</label> <?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Descripción breve del producto, no debe exceder los 255 caracteres. Este campo es obligatorio."></span> <?php endif; ?>
                                                    <textarea name="descripcion_small" class="form-control" id="text-descripcion" maxlength="255" rows="4" placeholder="Descripción corta del producto" required><?php echo e(old('descripcion_small')); ?></textarea>
                                                    <?php if ($errors->has('descripcion_small')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('descripcion_small'); ?>
                                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <label for="">Imagen(es)</label> <?php if(setting('admin.tips')): ?> <span class="voyager-question text-default pull-right" data-toggle="tooltip" data-placement="left" title="Imagen o imagenes que se mostrarán del producto. Este campo no es obligatorio."></span> <?php endif; ?>
                                                    <div class="img-small-wrap" style="height:120px;overflow-y:auto;border:3px solid #096FA9;padding:5px">
                                                        <div class="item-gallery" id="img-preview">
                                                            <button type="button" class="btn" title="Agregar imagen(es)" onclick="add_img()">
                                                                <h1 style="font-size:50px;margin:10px"><span class="voyager-plus"></span></h1>
                                                            </button>
                                                        </div>
                                                        <input type="file" name="imagen[]" style="display:none" accept="image/*" multiple id="gallery-photo-add">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <label for="">Insumos</label> <?php if(setting('admin.tips')): ?> <span class="voyager-question text-default pull-right" data-toggle="tooltip" data-placement="left" title="Inusumos necesarios para la elaboración del producto. Este campo no es obligatorio."></span> <?php endif; ?>
                                                    <div class="input-group">
                                                        <select id="select-insumo_id" class="form-control select2">
                                                            <?php $__currentLoopData = $insumos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option data-unidad="<?php echo e($item->unidad); ?>" value="<?php echo e($item->id); ?>" ><?php echo e($item->nombre); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                        <span class="input-group-btn">
                                                            <button class="btn btn-primary" id="btn-add" style="margin-top:0px" type="button"><span class="voyager-plus" aria-hidden="true"></span> Agregar</button>
                                                        </span>
                                                    </div>
                                                    <div style="max-height:200px;overflow-y:auto">
                                                        <table class="table table-bordered table-hover" >
                                                            <thead>
                                                                <tr>
                                                                    <th>Insumo</th>
                                                                    <th>Cantidad</th>
                                                                    <th>Unid.</th>
                                                                    <th></th>
                                                                </tr>
                                                                <tbody id="lista-insumos"></tbody>
                                                            </thead>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-bordered">
                                <div class="panel-heading">
                                    <h4 class="panel-title"> Descripción para la página de delivery <?php if(setting('admin.tips')): ?> <span class="voyager-question text-default" data-toggle="tooltip" data-placement="right" title="Descripción del producto que será visualizada por sus clientes cuando se encuentre agregada a la página de delivery. Este campo no es obligatorio."></span> <?php endif; ?></h4>
                                    <div class="panel-actions">
                                        <a class="panel-action panel-collapsed voyager-angle-down" data-toggle="panel-collapse" aria-hidden="true"></a>
                                    </div>
                                </div>
                                <div class="panel-body collapse">
                                    <div class="form-group">
                                        <textarea class="form-control richTextBox" name="descripcion_long" row="3"><?php echo e(old('descripcion_long')); ?></textarea>
                                    </div>
                                </div>
                                <div class="panel-footer">
                                    <input type="checkbox" checked id="permanecer" name="permanecer">
                                    <label for="permanecer">Guardar y permanecer aqui.</label>
                                    <br><br>
                                    <button type="submit" class="btn btn-primary">Guardar</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>


        </div>
        <?php echo $__env->make('partials.modal_load', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('css'); ?>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('javascript'); ?>
        <script src="<?php echo e(url('image-preview/image-preview.js')); ?>"></script>
        <script src="<?php echo e(url('js/loginweb.js')); ?>"></script>
        <script src="<?php echo e(url('js/inventarios/productos.js')); ?>"></script>
        <script>
            let insumo_indice = 1;
            $(document).ready(function(){
                $('[data-toggle="popover"]').popover({ html : true });
                $('[data-toggle="tooltip"]').tooltip();

                inicializar_select2('categoria_id');
                inicializar_select2('subcategoria_id');

                // Listar las subcategorias segun la categoria seleccionada
                $('#select-categoria_id').change(function(){
                    let id = $(this).val();
                    if(!isNaN(id)){
                        $.ajax({
                            url: '<?php echo e(url("admin/subcategorias/list/categoria")); ?>/'+id,
                            type: 'get',
                            success: function(response){
                                select2_reload('subcategoria_id', response, false, '');
                            }
                        });
                    }else{
                        $('#select-subcategoria_id').html('');
                        inicializar_select2('subcategoria_id');
                    }
                });
            });

            function borrarTr(num){
                $(`#tr-${num}`).remove();
            }
        </script>
    <?php $__env->stopSection(); ?>

<?php else: ?>
    <?php $__env->startSection('content'); ?>
        <?php echo $__env->make('errors.sin_permiso', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatcom\resources\views/inventarios/productos/restaurante/productos_create.blade.php ENDPATH**/ ?>