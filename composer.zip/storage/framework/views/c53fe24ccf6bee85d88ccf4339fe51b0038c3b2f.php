<?php $__env->startSection('page_title', 'Ofertas'); ?>

<?php if(auth()->user()->hasPermission('browse_ofertas')): ?>
    <?php $__env->startSection('page_header'); ?>
        <h1 class="page-title">
            <i class="voyager-certificate"></i>Campaña de Oferta
        </h1>
        <?php if(auth()->user()->hasPermission('add_ofertas')): ?>
        <a href="<?php echo e(route('ofertas_create')); ?>" class="btn btn-success btn-add-new">
            <i class="voyager-plus"></i> <span>Añadir nuevo</span>
        </a>
        <?php endif; ?>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>
        <div class="page-content">
            <div class="page-content browse container-fluid">
                <?php echo $__env->make('voyager::alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-bordered">
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-8"></div>
                                        <form id="form-search" class="form-search">
                                            <div class="input-group col-md-4">
                                                <input type="text" id="search_value" class="form-control" name="s" value="<?php echo e($value); ?>" placeholder="Ingresar busqueda...">
                                                <span class="input-group-btn">
                                                    <button class="btn btn-default" style="margin-top:0px;padding:5px 10px" type="submit">
                                                        <i class="voyager-search"></i>
                                                    </button>
                                                </span>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <div class="table-responsive">
                                    <table id="dataTable" class="table table-bordered table-hover">
                                        <thead>
                                            <tr>
                                                <th>Nombre</th>
                                                <th>Descripción</th>
                                                <th>Fecha de inicio</th>
                                                <th>Fecha de fin</th>
                                                <th>Imagen</th>
                                                <th class="actions text-right">Acciones</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <?php
                                                    $img = ($item->imagen!='') ? $item->imagen : 'ofertas/default.png';
                                                ?>
                                                <tr>
                                                    <td><?php echo e($item->nombre); ?></td>
                                                    <td><?php echo e($item->descripcion); ?></td>
                                                    <td><?php echo e(date('d-m-Y', strtotime($item->inicio))); ?> <br> <small><?php echo e(\Carbon\Carbon::parse($item->inicio)->diffForHumans()); ?></small> </td>
                                                    <td>
                                                        <?php if($item->fin!=''): ?>
                                                        <?php echo e(date('d-m-Y', strtotime($item->fin))); ?> <br> <small><?php echo e(\Carbon\Carbon::parse($item->fin)->diffForHumans()); ?></small>
                                                        <?php else: ?>
                                                        No definido
                                                        <?php endif; ?>
                                                    </td>
                                                    <td><a href="<?php echo e(url('storage').'/'.$img); ?>" data-fancybox="galeria1" data-caption="<?php echo e($item->nombre); ?>"><img src="<?php echo e(url('storage').'/'.$img); ?>" width="50px" alt=""></a></td>
                                                    <td class="no-sort no-click text-right" id="bread-actions">
                                                        <?php if(auth()->user()->hasPermission('read_ofertas')): ?>
                                                        <a href="<?php echo e(route('ofertas_view', ['id' => $item->id])); ?>" title="Ver" class="btn btn-sm btn-warning view">
                                                            <i class="voyager-eye"></i> <span class="hidden-xs hidden-sm">Ver</span>
                                                        </a>
                                                        <?php endif; ?>
                                                        <?php if(auth()->user()->hasPermission('edit_ofertas')): ?>
                                                        <a href="<?php echo e(route('ofertas_edit', ['id'=>$item->id])); ?>" title="Editar" class="btn btn-sm btn-primary edit">
                                                            <i class="voyager-edit"></i> <span class="hidden-xs hidden-sm">Editar</span>
                                                        </a>
                                                        <?php endif; ?>
                                                        <?php if(auth()->user()->hasPermission('delete_ofertas')): ?>
                                                        <a href="#" title="Borrar" class="btn btn-sm btn-danger btn-delete" data-id="<?php echo e($item->id); ?>" data-toggle="modal" data-target="#modal_delete">
                                                            <i class="voyager-trash"></i> <span class="hidden-xs hidden-sm">Borrar</span>
                                                        </a>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="7"><p class="text-center"><br>No hay registros para mostrar.</p></td>
                                            </tr>
                                        <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="col-md-12">
                                    <div class="col-md-6" style="overflow-x:auto">
                                        <?php if(count($registros)>0): ?>
                                            <p class="text-muted">Mostrando del <?php echo e($registros->firstItem()); ?> al <?php echo e($registros->lastItem()); ?> de <?php echo e($registros->total()); ?> registros.</p>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md-6" style="overflow-x:auto">
                                        <nav class="text-right">
                                            <?php echo e($registros->links()); ?>

                                        </nav>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <form action="<?php echo e(route('ofertas_delete')); ?>" method="POST">
            <div class="modal modal-danger fade" tabindex="-1" id="modal_delete" role="dialog">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                        aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title">
                                <i class="voyager-trash"></i> Estás seguro que quieres borrar el siguiente registro?
                            </h4>
                        </div>

                        <div class="modal-body">
                        </div>
                        <div class="modal-footer">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="id" value="">
                            <input type="submit" class="btn btn-danger pull-right delete-confirm"value="Sí, bórralo!">
                            <button type="button" class="btn btn-default pull-right" data-dismiss="modal">
                                Cancelar
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('css'); ?>
        <link href="<?php echo e(url('ecommerce/plugins/fancybox/fancybox.min.css')); ?>" type="text/css" rel="stylesheet">
        <style>

        </style>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('javascript'); ?>
        <script src="<?php echo e(url('ecommerce/plugins/fancybox/fancybox.min.js')); ?>" type="text/javascript"></script>
        <script>
            $(document).ready(function() {

                // set valor de delete
                $('.btn-delete').click(function(){
                    $('#modal_delete input[name="id"]').val($(this).data('id'));
                });

                // enviar formulario de busqueda
                $('#form-search').on('submit', function(e){
                    e.preventDefault();
                    let value = (escape($('#search_value').val())!='') ? escape($('#search_value').val()) : 'all';
                    window.location = '<?php echo e(url("admin/ofertas/buscar")); ?>/'+value;
                });
            });
        </script>
    <?php $__env->stopSection(); ?>

<?php else: ?>
    <?php $__env->startSection('content'); ?>
        <?php echo $__env->make('errors.sin_permiso', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatcom\resources\views/inventarios/ofertas/ofertas_index.blade.php ENDPATH**/ ?>