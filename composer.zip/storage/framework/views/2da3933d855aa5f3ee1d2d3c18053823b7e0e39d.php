<div class="sidebar" :class="[{'is-hidden': ! sidebar}]">
    <?php echo $index; ?>

</div><?php /**PATH C:\xampp\htdocs\fatcom\resources\views/vendor/larecipe/partials/sidebar.blade.php ENDPATH**/ ?>