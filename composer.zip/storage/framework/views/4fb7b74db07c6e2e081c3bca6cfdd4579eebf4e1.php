<?php $__env->startSection('page_title', 'Añadir Cliente'); ?>

<?php if(auth()->user()->hasPermission('add_clientes')): ?>
    <?php $__env->startSection('page_header'); ?>
        <h1 class="page-title">
            <i class="voyager-people"></i> Añadir Cliente
        </h1>
        
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
        <div class="page-content">
            <div class="page-content browse container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-bordered">
                            <form action="<?php echo e(route('clientes_store')); ?>" method="post">
                                <div class="panel-body strong-panel">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="row">
                                                <div class="col-md-6 form-group">
                                                    <label for="">Nombre o razón social</label> <?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Nombre o razón social del cliente. Este campo es obligatorio."></span> <?php endif; ?>
                                                    <input type="text" name="razon_social" class="form-control" value="<?php echo e(old('razon_social')); ?>" placeholder="Nombre o razón social del cliente" required>
                                                    <?php if ($errors->has('razon_social')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('razon_social'); ?>
                                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                                <div class="col-md-6 form-group">
                                                    <label for="">NIT o CI</label> <?php if(setting('admin.tips')): ?> <span class="voyager-question text-default pull-right" data-toggle="tooltip" data-placement="left" title="NIT o CI del cliente. Este campo no es obligatorio."></span> <?php endif; ?>
                                                    <input type="text" name="nit" class="form-control" value="<?php echo e(old('nit')); ?>" placeholder="NIT o CI">
                                                    <?php if ($errors->has('nit')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nit'); ?>
                                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6 form-group">
                                                    <label for="">Movil</label> <?php if(setting('admin.tips')): ?> <span class="voyager-question text-default pull-right" data-toggle="tooltip" data-placement="left" title="Número de celular del cliente. Este campo no es obligatorio."></span> <?php endif; ?>
                                                    <input type="number" name="movil" class="form-control" value="<?php echo e(old('movil')); ?>" placeholder="Número celular" maxlength="20">
                                                    <?php if ($errors->has('movil')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('movil'); ?>
                                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                                <div class="col-md-6 form-group">
                                                    <label for="">Ninkname</label> <?php if(setting('admin.tips')): ?> <span class="voyager-question text-default pull-right" data-toggle="tooltip" data-placement="left" title="Nombre corto que se mostrará cuando el usuario inicie sesión. Este campo no es obligatorio."></span> <?php endif; ?>
                                                    <input type="text" name="nickname" class="form-control" value="<?php echo e(old('nickname')); ?>" placeholder="Nombre para mostrar" maxlength="20">
                                                    <?php if ($errors->has('nickname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nickname'); ?>
                                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6 form-group">
                                                    <label for="">Email</label> <?php if(setting('admin.tips')): ?> <span class="voyager-question text-default pull-right" data-toggle="tooltip" data-placement="left" title="Email del cliente para iniciar sesión en el sistema. Este campo solo es obligatorio si se va a crear un usuario al cliente."></span> <?php endif; ?>
                                                    <input type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>" placeholder="Email" maxlength="50">
                                                    <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                                <div class="col-md-6 form-group">
                                                    <label for="">Password</label> <?php if(setting('admin.tips')): ?> <span class="voyager-question text-default pull-right" data-toggle="tooltip" data-placement="left" title="Contraseña del cliente para iniciar sesión en el sistema, el usuario tiene la opción de cambiar su contraseña cuando desee. Este campo solo es obligatorio si se va a crear un usuario al cliente."></span> <?php endif; ?>
                                                    <input type="password" name="password" class="form-control" placeholder="Password" maxlength="20">
                                                    <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <input type="checkbox" id="permanecer" name="permanecer">
                                        <label for="permanecer">Guardar y permanecer aqui.</label>
                                        <br><br>
                                        <button type="submit" class="btn btn-primary">Guardar</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('css'); ?>
        <style>

        </style>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('javascript'); ?>
        <script>
            $(document).ready(function(){
                $('[data-toggle="tooltip"]').tooltip();
            });
        </script>
    <?php $__env->stopSection(); ?>

<?php else: ?>
    <?php $__env->startSection('content'); ?>
        <?php echo $__env->make('errors.sin_permiso', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatcom\resources\views/clientes/clientes_create.blade.php ENDPATH**/ ?>