<?php $__env->startSection('page_title', 'Añadir producto a E-Commerce'); ?>

<?php if(auth()->user()->hasPermission('add_ecommerce')): ?>
    <?php $__env->startSection('page_header'); ?>
        <h1 class="page-title">
            <i class="voyager-basket"></i> Añadir producto
        </h1>
        
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
        <div class="page-content">
            <form name="form" action="<?php echo e(route('ecommerce_store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="page-content browse container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-bordered">
                                <div class="panel-heading">
                                    <h4 class="panel-title" style="padding:0px 15px"> Lista de productos
                                        <button type="button" style="font-size:20px" class="btn btn-link" title="Ver filtros" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                            <span class="voyager-params"></span>
                                        </button>
                                    </h4>
                                </div>
                                <div class="panel-body" style="padding-top:0px">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div id="accordion">
                                                <div class="card">
                                                    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
                                                        <div class="card-body">
                                                            <div class="row">
                                                                <div class="form-group col-md-4">
                                                                    <label for="">Categoria</label>
                                                                    <select id="select-categoria_id" class="form-control select2 select-filtro">
                                                                        <option value="">Todas</option>
                                                                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($item->id); ?>" ><?php echo e($item->nombre); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </div>
                                                                <div class="form-group col-md-4">
                                                                    <label for="">Sub categoria</label>
                                                                    <select id="select-subcategoria_id" class="form-control select2 select-filtro">
                                                                        <option value="">Todas</option>
                                                                    </select>
                                                                </div>
                                                                <div class="form-group col-md-4">
                                                                    <label for="">Marca</label>
                                                                    <select id="select-marca_id" class="form-control select2 select-filtro">
                                                                        <option value="">Todas</option>
                                                                        <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($item->id); ?>" ><?php echo e($item->nombre); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <label for="">Producto</label> <?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Producto que se agregará al E-Commerce. Este campo es obligatorio."></span> <?php endif; ?>
                                            <div class="input-group">
                                                <select class="form-control select2" id="select-producto_id">
                                                        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($item->id); ?>"> <?php echo e($item->subcategoria); ?> - <?php echo e($item->nombre); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                <span class="input-group-btn">
                                                    <button style="margin-top:0px;padding:8px" id="btn-agregar" type="button" class="btn btn-success">Añadir <span class="voyager-plus"></span></button>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="input-group">
                                                <input type="text" id="input-tags" data-role="tagsinput" class="form-control" name="tags" placeholder="Etiquetas">
                                                <span class="input-group-addon" style="margin-top:0px;padding:7px">
                                                    <?php if(setting('admin.tips')): ?> <span class="voyager-question text-default" data-toggle="tooltip" data-placement="left" title="Palabras claves que asociarán el producto con otros para hacer recomendaciones a la hora de buscar en el E-Commerce. Este campo no es obligatorio."></span> <?php endif; ?>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="table-responsive">
                                                <table class="table table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <th>Producto</th>
                                                            <th width="100px">En escasez</th>
                                                            <th>Etiquetas</th>
                                                            <th width="50px">Quitar</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody id="lista_productos">

                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <hr>
                                    <h4>Costos de envío <?php if(setting('admin.tips')): ?> <span style="font-size:15px" class="voyager-question text-default" data-toggle="tooltip" data-placement="right" title="Costos de envío del producto a las diferentes localidades, si el producto no se envía a esa localidad dejar el campo vacío y si el envío es gratis ingresar 0. Este campo no es obligatorio."></span> <?php endif; ?></h4>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="table-responsive">
                                                <table class="table table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <th>Departamento</th>
                                                            <th>Localidad</th>
                                                            <th style="width:200px">Precio</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $localidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td>
                                                                <?php echo e($item->departamento); ?>

                                                                <input type="hidden" name="localidad_id[]" value="<?php echo e($item->id); ?>" class="form-control">
                                                            </td>
                                                            <td><?php echo e($item->localidad); ?></td>
                                                            <td>
                                                                <div class="input-group">
                                                                    <input type="number" name="precio[]" class="form-control">
                                                                    <span class="input-group-addon" style="margin-top:0px;padding:7px">Bs.</span>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel-footer">
                                    <button type="button" id="btn-submit" class="btn btn-primary">Guardar</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <?php echo $__env->make('partials.modal_load', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('css'); ?>
        <link rel="stylesheet" href="<?php echo e(url('input-multiple/bootstrap-tagsinput.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(url('input-multiple/app.css')); ?>">
        <style>
            .popover{
                width: 300px;
            }
        </style>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('javascript'); ?>
        <script src="<?php echo e(url('image-preview/image-preview.js')); ?>"></script>
        <script src="<?php echo e(url('input-multiple/bootstrap-tagsinput.js')); ?>"></script>
        <script src="<?php echo e(url('input-multiple/app.js')); ?>"></script>
        <script src="<?php echo e(url('js/loginweb.js')); ?>"></script>
        <script>
        $(document).ready(function(){
            $('[data-toggle="popover"]').popover({ html : true });
            $('[data-toggle="tooltip"]').tooltip();
            $('#input-tags').tagsinput({});

            <?php if ($errors->has('producto_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('producto_id'); ?>
            toastr.error('Debe agregar al menos 1 producto a la lista.', 'Error');
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

            // Obtener subcategorias de una categoria
            $('#select-categoria_id').change(function(){
                let id = $(this).val();
                if(id!=''){
                    $.ajax({
                        url: '<?php echo e(url("admin/subcategorias/list/categoria")); ?>/'+id,
                        type: 'get',
                        success: function(response){
                            select2_reload_simple('subcategoria_id', response, false, '');

                            // agregar opcion por defecto
                            $('#select-subcategoria_id').prepend(`<option value="">Todas</option>`);
                            $('#select-subcategoria_id').select2('destroy');
                            $('#select-subcategoria_id').val('');
                            $('#select-subcategoria_id').select2();
                        }
                    });
                }else{
                    select2_reload_simple('subcategoria_id', [{'id':'','nombre':'Todas'}], false, '');
                }
            });

            // Obtener marcas de una subcategoria
            $('#select-subcategoria_id').change(function(){
                let id = $(this).val();
                if(id!=''){
                    $.ajax({
                        url: '<?php echo e(url("admin/marcas/list/subcategoria")); ?>/'+id,
                        type: 'get',
                        success: function(response){
                            select2_reload_simple('marca_id', response, false, '');

                            // agregar opcion por defecto
                            $('#select-marca_id').prepend(`<option value="">Todas</option>`);
                            $('#select-marca_id').select2('destroy');
                            $('#select-marca_id').val('');
                            $('#select-marca_id').select2();
                        }
                    });
                }else{
                    select2_reload_simple('marca_id', [{'id':'','nombre':'Todas'}], false, '');
                }
            });

            // realizar filtro
            $('.select-filtro').change(function(){
                let categoria = $('#select-categoria_id').val() ? $('#select-categoria_id').val() : 'all';
                let subcategoria = $('#select-subcategoria_id').val() ? $('#select-subcategoria_id').val() : 'all';
                let marca = $('#select-marca_id').val() ? $('#select-marca_id').val() : 'all';

                // evitar que se envie una sub categoria si no se esta enviando una categoria
                if(categoria == 'all'){
                    subcategoria = 'all';
                }

                $.ajax({
                    url: '<?php echo e(url("admin/ecommerce/filtros/filtro_simple")); ?>/'+categoria+'/'+subcategoria+'/'+marca,
                    type: 'get',
                    success: function(response){
                        select2_reload_simple('producto_id', response, false, '');
                    }
                });
            });

            // agregar productos
            let indice = 1;
            $('#btn-agregar').click(function(){
                let id = $('#select-producto_id').val();
                let nombre = $('#select-producto_id option:selected').text();
                let envio = $('#input-envio').val();
                let envio_rapido = $('#input-envio_rapido').val();
                let tags = $('#input-tags').val();

                if(id!=null){

                    // Verificar que el producto no se haya seleccionado antes
                    let existe = false
                    $(".input-producto_id").each(function(){
                        if($(this).val()==id){
                            existe = true;
                        }
                    });
                    if(existe){
                        toastr.warning('El producto seleccionado ya se encuentra en la lista.', 'Advertencia');
                        return false;
                    }

                    // Crear fila con datos del producto
                    $('#lista_productos').append(`<tr id="tr-${indice}">
                                                    <td><input type="hidden" class="input-producto_id" name="producto_id[]" value="${id}">${nombre}</td>
                                                    <td><select name="escasez[]" class="form-control" id="">
                                                            <option value="">No</option>
                                                            <option value="1">Si</option>
                                                        </select></td>
                                                    <td><input type="hidden" class="form-control" name="tags[]" value="${tags}">${tags}</td>
                                                    <td style="padding-top:15px"><span onclick="borrarTr(${indice})" class="voyager-x text-danger"></span></td>
                                                </tr>`);
                indice++;
                }else{
                    toastr.warning('Debe seleccionar un producto.', 'Advertencia');
                }
            });

            $('#btn-submit').click(function(){
                document.form.submit();
            });

            // ================
        });

        function borrarTr(id){
            console.log(id)
            $('#tr-'+id).remove();
        }
    </script>
    <?php $__env->stopSection(); ?>

<?php else: ?>
    <?php $__env->startSection('content'); ?>
        <?php echo $__env->make('errors.sin_permiso', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatcom\resources\views/inventarios/ecommerce/ecommerce_create.blade.php ENDPATH**/ ?>