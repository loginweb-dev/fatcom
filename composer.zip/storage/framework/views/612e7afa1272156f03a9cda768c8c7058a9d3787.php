<?php $__env->startSection('page_title', 'Editar Producto'); ?>

<?php if(auth()->user()->hasPermission('edit_productos')): ?>
    <?php $__env->startSection('page_header'); ?>
        <h1 class="page-title">
            <i class="voyager-harddrive"></i> editar producto
        </h1>
        
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
        <div class="page-content">
            <form id="form" action="<?php echo e(route('productos_update')); ?>" method="post" enctype="multipart/form-data">
                <div class="page-content browse container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-bordered">
                                <?php echo csrf_field(); ?>
                                
                                <input type="hidden" name="unidad_id" value="1">
                                <input type="hidden" name="talla_id" value="1">
                                <input type="hidden" name="color_id" value="1">
                                <input type="hidden" name="genero_id" value="1">
                                <input type="hidden" name="uso_id" value="1">
                                
                                <input type="hidden" name="id" value="<?php echo e($producto->id); ?>">
                                
                                <div class="panel-body strong-panel">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="form-group col-md-12">
                                                    <label for="">Nombre comercial</label> <?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Nombre comercial del producto. Este campo es obligatorio."></span> <?php endif; ?>
                                                    <input type="text" name="nombre" value="<?php echo e($producto->nombre); ?>" class="form-control" placeholder="Nombre del producto" required>
                                                    <?php if ($errors->has('nombre')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nombre'); ?>
                                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                    <div  style="position:absolute;right:15px;top:27px">
                                                        <input type="checkbox" id="input-nuevo" name="nuevo" data-toggle="toggle" data-on="<span class='voyager-check'></span> Nuevo" data-off="<span class='voyager-x'></span> Nuevo">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-md-6">
                                                    <label for="">Código</label> <?php if(setting('admin.tips')): ?> <span class="voyager-question text-default pull-right" data-toggle="tooltip" data-placement="left" title="Código de identificación del producto. Este campo no es obligatorio."></span> <?php endif; ?>
                                                    <input type="text" name="codigo_interno" value="<?php echo e($producto->codigo_interno); ?>" class="form-control" placeholder="Código del producto">
                                                </div>
                                                <div class="form-group col-md-6">
                                                    <label for="">Moneda</label> <?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Moneda de comercialización del producto. Este campo es obligatorio."></span> <?php endif; ?>
                                                    <select name="moneda_id" id="select-moneda_id" class="form-control select2" required>
                                                        <?php $__currentLoopData = $monedas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($item->id); ?>" ><?php echo e($item->nombre); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-md-6">
                                                    <label for="">Categoría</label> <?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Categoría a la que pertenece el producto. Este campo es obligatorio."></span> <?php endif; ?>
                                                    <select name="categoria_id" id="select-categoria_id" class="form-control select2" required>
                                                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($item->id); ?>" ><?php echo e($item->nombre); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="form-group col-md-6">
                                                    <label for="">Sub categoría</label> <?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Sub categoría del producto. las subcategorías se despliegan en base a la categoría seleccionada previamente. Este campo es obligatorio."></span> <?php endif; ?>
                                                    <div id="div-select_subcategorias">
                                                        <select name="subcategoria_id" id="select-subcategoria_id" class="form-control select2" required>
                                                            <?php $__currentLoopData = $subcategorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($item->id); ?>" ><?php echo e($item->nombre); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-md-6">
                                                    <label for="">Marca</label> <?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Marca del producto. Este campo es obligatorio."></span> <?php endif; ?>
                                                    <select name="marca_id" id="select-marca_id" class="form-control" required>
                                                        <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($item->id); ?>" ><?php echo e($item->nombre); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="form-group col-md-6">
                                                    <label for="">Modelo</label> <?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Modelo del producto. Este campo es obligatorio."></span> <?php endif; ?>
                                                    <input type="text" name="modelo" value="<?php echo e($producto->modelo); ?>" class="form-control" placeholder="Modelo del producto" required>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-md-6">
                                                    <label for="">Garantía</label> <?php if(setting('admin.tips')): ?> <span class="voyager-question text-default pull-right" data-toggle="tooltip" data-placement="left" title="Garantía del producto. Este campo no es obligatorio."></span> <?php endif; ?>
                                                    <input type="text" name="garantia" value="<?php echo e($producto->garantia); ?>" class="form-control" placeholder="12 meses">
                                                </div>
                                                <div class="form-group col-md-6">
                                                    <label for="">Cantidad</label> <?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Cantidad de productos en stock. Este campo es obligatorio."></span> <?php endif; ?>
                                                    <input type="number" name="stock" readonly class="form-control" value="<?php echo e($producto->stock); ?>" min="0" step="1" required>
                                                    <div  style="position:absolute;right:15px;top:27px">
                                                        <input type="checkbox" id="input-se_almacena" name="se_almacena" data-toggle="toggle" data-on="<small>Se almacena</small> <span class='voyager-check'></span>" data-off="<small>Se almacena</small> <span class='voyager-x'></span>">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-md-12">
                                                    <label for="">Catálogo</label> <?php if(setting('admin.tips')): ?> <span class="voyager-question text-default pull-right" data-toggle="tooltip" data-placement="left" title="Catálogo del producto. Este campo no es obligatorio."></span> <?php endif; ?>
                                                    <input type="file" name="catalogo" class="form-control">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-md-12">
                                                    <label for="" id="label-descripcion"></label> <?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Descripción breve del producto, no debe exceder los 255 caracteres. Este campo es obligatorio."></span> <?php endif; ?>
                                                    <textarea name="descripcion_small" class="form-control" id="text-descripcion" maxlength="255" rows="2" placeholder="Descripción corta del producto" required><?php echo e($producto->descripcion_small); ?></textarea>
                                                    <?php if ($errors->has('descripcion_small')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('descripcion_small'); ?>
                                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <article class="gallery-wrap">
                                                <div class="img-big-wrap card-banner" style="text-align:center;height:370px">
                                                    <article class="overlay top text-center">
                                                        <h4 class="title mb-0">Imagen principal del producto</h4>
                                                    </article>
                                                    <?php
                                                        $img = ($producto->imagen!='') ? str_replace('.', '_medium.', $producto->imagen) : 'productos/default.png';
                                                        $img_big = ($producto->imagen!='') ? $producto->imagen : 'productos/default.png';
                                                    ?>
                                                    <a id="img-slider" href="<?php echo e(url('storage').'/'.$img_big); ?>" data-fancybox="slider1">
                                                        <img id="img-medium" class="img-thumbnail img-sm" src="<?php echo e(url('storage').'/'.$img); ?>">
                                                    </a>
                                                </div>
                                                <div class="img-small-wrap">
                                                    <?php
                                                        $style = ($producto->imagen!='') ? 'border:3px solid #2ECC71' : '';
                                                        $imagen_principal = 0;
                                                    ?>
                                                    <?php $__currentLoopData = $imagen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                            $img = str_replace('.', '_small.', $item->imagen);
                                                            $img_big = $item->imagen;
                                                            if(!empty($style)){
                                                                $imagen_principal = $item->id;
                                                            }
                                                        ?>
                                                        <div class="item-gallery" id="image-<?php echo e($item->id); ?>" style="<?php echo e($style); ?>">
                                                            <div style="position:absolute;z-index:1;">
                                                                <label class="label label-danger btn-delete_img" data-toggle="modal" data-id="<?php echo e($item->id); ?>" data-target="#modal_delete" style="cursor:pointer;margin-left:30px;<?php if(!empty($style)): ?> display:none <?php endif; ?>"><span class="voyager-x"></span></label>
                                                            </div>
                                                            <img src="<?php echo e(url('storage').'/'.$img); ?>" class="img-thumbnail img-sm img-gallery" data-id="<?php echo e($item->id); ?>" data-img="<?php echo e(url('storage').'/'.$img_big); ?>">
                                                        </div>
                                                        <?php
                                                            $style = '';
                                                        ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </article>
                                            <div class="col-md-12" style="">
                                                <div class="img-small-wrap" style="height:120px;overflow-y:auto;border:3px solid #096FA9;padding:5px">
                                                    <div class="item-gallery" id="img-preview">
                                                        <button type="button" class="btn" title="Agregar imagen(es)" onclick="add_img()">
                                                            <h1 style="font-size:50px;margin:10px"><span class="voyager-plus"></span></h1>
                                                        </button>
                                                    </div>
                                                    <input type="file" name="imagen[]" style="display:none" accept="image/*" multiple id="gallery-photo-add">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="panel panel-bordered">
                                <div class="panel-heading">
                                    <h3 class="panel-title"><i class="icon wb-image"></i> Precio(s) de compra <button type="button" class="btn btn-success btn-small" id="btn-add_compra" title="Agregar precio"><span class="voyager-plus"></span></button></h3>
                                    <div class="panel-actions">
                                        <a class="panel-action voyager-angle-up" data-toggle="panel-collapse" aria-hidden="true"></a>
                                    </div>
                                </div>
                                <div class="panel-body">
                                    <table class="table table-bordered">
                                        <thead>
                                            <th>Precio <?php if(setting('admin.tips')): ?> <span class="voyager-question text-default pull-right" data-toggle="tooltip" data-placement="left" title="Precio de compra del producto. Este campo no es obligatorio."></span> <?php endif; ?></th>
                                            <th>Cantidad mínima <?php if(setting('admin.tips')): ?> <span class="voyager-question text-default pull-right" data-toggle="tooltip" data-placement="left" title="Cantidad mínima de compra para tener dicho precio. Este campo no es obligatorio."></span> <?php endif; ?></th>
                                            <th></th>
                                        </thead>
                                        <tbody id="tr-precioCompra">
                                            <?php
                                                $indiceCompra = 0;
                                            ?>
                                            <?php for($i = 0; $i < count($precio_compra); $i++): ?>
                                                <?php if($i==0): ?>
                                                <tr>
                                                    <td><input type="number" min="1" step="0.1" class="form-control" value="<?php echo e($precio_compra[$i]->monto); ?>" name="monto[]"></td>
                                                    <td><input type="number" min="1" step="1" class="form-control" value="<?php echo e($precio_compra[$i]->cantidad_minima); ?>" name="cantidad_minima_compra[]"></td>
                                                    <td style="padding-top:15px"><span class="voyager-x text-secondary"></span></td>
                                                </tr>
                                                <?php else: ?>
                                                    <tr id="tr-precioCompra<?php echo e($indiceCompra); ?>">
                                                        <td><input type="number" min="1" step="0.1" class="form-control" value="<?php echo e($precio_compra[$i]->monto); ?>" name="monto[]" required></td>
                                                        <td><input type="number" min="1" step="1" class="form-control" value="<?php echo e($precio_compra[$i]->cantidad_minima); ?>" name="cantidad_minima_compra[]" required></td>
                                                        <td style="padding-top:15px"><span onclick="borrarTr(<?php echo e($indiceCompra); ?>, 'Compra')" class="voyager-x text-danger"></span></td>
                                                    </tr>
                                                <?php endif; ?>
                                                <?php
                                                    $indiceCompra++;
                                                ?>
                                            <?php endfor; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="panel panel-bordered">
                                <div class="panel-heading">
                                    <h3 class="panel-title"><i class="icon wb-image"></i> Precio(s) de venta <button type="button" class="btn btn-success btn-small" id="btn-add_venta" title="Agregar precio"><span class="voyager-plus"></span></button></h3>
                                    <div class="panel-actions">
                                        <a class="panel-action voyager-angle-up" data-toggle="panel-collapse" aria-hidden="true"></a>
                                    </div>
                                </div>
                                <div class="panel-body">
                                    <table class="table table-bordered">
                                        <thead>
                                            <th>Precio <?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Precio de venta del producto. Este campo es obligatorio."></span> <?php endif; ?></th>
                                            <th>Cantidad mínima <?php if(setting('admin.tips')): ?> <span class="voyager-question text-info pull-right" data-toggle="tooltip" data-placement="left" title="Cantidad mínima de venta para tener dicho precio. Este campo es obligatorio."></span> <?php endif; ?></th>
                                            <th></th>
                                        </thead>
                                        <tbody id="tr-precioVenta">
                                            <?php
                                                $indiceVenta = 0;
                                            ?>
                                            <?php for($i = 0; $i < count($precio_venta); $i++): ?>
                                                <?php if($i==0): ?>
                                                <tr>
                                                    <td>
                                                        <input type="number" min="1" step="0.1" class="form-control" value="<?php echo e($precio_venta[$i]->precio); ?>" name="precio_venta[]" required>
                                                        <input type="hidden" name="precio_minimo[]" value="0">
                                                    </td>
                                                    <td><input type="number" min="1" step="1" class="form-control" value="<?php echo e($precio_venta[$i]->cantidad_minima); ?>" name="cantidad_minima_venta[]" required></td>
                                                    <td style="padding-top:15px"><span class="voyager-x text-secondary"></span></td>
                                                </tr>
                                                <?php else: ?>
                                                    <tr id="tr-precioVenta<?php echo e($indiceVenta); ?>">
                                                        <td><input type="number" min="1" step="0.1" class="form-control" value="<?php echo e($precio_venta[$i]->precio); ?>" name="precio_venta[]" required></td>
                                                        <td><input type="number" min="1" step="1" class="form-control" value="<?php echo e($precio_venta[$i]->cantidad_minima); ?>" name="cantidad_minima_venta[]" required></td>
                                                        <td style="padding-top:15px"><span onclick="borrarTr(<?php echo e($indiceVenta); ?>, 'Venta')" class="voyager-x text-danger"></span></td>
                                                    </tr>
                                                <?php endif; ?>
                                                <?php
                                                    $indiceVenta++;
                                                ?>
                                            <?php endfor; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-bordered">
                                <div class="panel-heading">
                                        <h4 class="panel-title"> Descripción para E-Commerce <?php if(setting('admin.tips')): ?> <span class="voyager-question text-default" data-toggle="tooltip" data-placement="right" title="Descripción del producto que será visualizada por sus clientes cuando se encuentre agregada al E-Commerca. Este campo no es obligatorio."></span> <?php endif; ?></h4>
                                    <div class="panel-actions">
                                        <a class="panel-action panel-collapsed voyager-angle-down" data-toggle="panel-collapse" aria-hidden="true"></a>
                                    </div>
                                </div>
                                <div class="panel-body <?php if($producto->descripcion_long == ''): ?> collapse <?php endif; ?>">
                                    <div class="form-group">
                                        <textarea class="form-control richTextBox" name="descripcion_long" row="3"><?php echo e($producto->descripcion_long); ?></textarea>
                                    </div>
                                </div>
                                <div class="panel-footer">
                                    <button type="submit" class="btn btn-primary">Guardar</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <?php echo $__env->make('partials.modal_load', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('inventarios.productos.partials.modales', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('css'); ?>
        <link href="<?php echo e(url('ecommerce/plugins/fancybox/fancybox.min.css')); ?>" type="text/css" rel="stylesheet">
        <!-- custom style -->
        <link href="<?php echo e(url('ecommerce/css/ui.css')); ?>" rel="stylesheet" type="text/css"/>
        <link href="<?php echo e(url('ecommerce/css/responsive.css')); ?>" rel="stylesheet" media="only screen and (max-width: 1200px)" />
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('javascript'); ?>
    <script src="<?php echo e(url('image-preview/image-preview.js')); ?>"></script>
    <script src="<?php echo e(url('ecommerce/plugins/fancybox/fancybox.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(url('js/loginweb.js')); ?>"></script>
    <script src="<?php echo e(url('js/inventarios/productos.js')); ?>"></script>
        <script>
            $(document).ready(function(){
                $('[data-toggle="popover"]').popover({ html : true });
                $('[data-toggle="tooltip"]').tooltip();

                if('<?php echo e($producto->nuevo); ?>'=='1'){
                    $('#input-nuevo').bootstrapToggle('on')
                }

                if('<?php echo e($producto->se_almacena); ?>'=='1'){
                    $('#input-se_almacena').bootstrapToggle('on')
                }

                $('#label-descripcion').text(`Descripción (${$('#text-descripcion').val().length}/255)`)

                $('#select-categoria_id').val('<?php echo e($producto->categoria_id); ?>');
                $('#select-subcategoria_id').val('<?php echo e($producto->subcategoria_id); ?>');
                $('#select-marca_id').val('<?php echo e($producto->marca_id); ?>');
                $('#select-moneda_id').val('<?php echo e($producto->moneda_id); ?>');

                // $('#select-categoria_id').select2();
                // $('#select-subcategoria_id').select2();
                // $('#select-marca_id').select2();
                $('#select-moneda_id').select2();
                inicializar_select2('categoria_id');
                inicializar_select2('subcategoria_id');
                inicializar_select2('marca_id');

                // cambiar imagen principal
                $('.img-gallery').click(function(){
                    let img_medium = $(this).data('img').replace('_small', '_medium');
                    let img = $(this).data('img').replace('_small', '');

                    let id = $(this).data('id');
                    let producto_id = <?php echo e($producto->id); ?>;
                    let url = "<?php echo e(url('admin/productos/cambiar_imagen_principal')); ?>/"+producto_id+'/'+id
                    change_background(img_medium, img, id, url)
                });

                // Eliminar imagen
                $('#form-delete_imagen').on('submit', function(e){
                    e.preventDefault();
                    let datos = $(this).serialize();
                    delete_imagen("<?php echo e(route('delete_imagen')); ?>", datos);
                });

                $('#select-categoria_id').change(function(){
                    let id = $(this).val();
                    if(!isNaN(id)){
                        $.ajax({
                            url: '<?php echo e(url("admin/subcategorias/list/categoria")); ?>/'+id,
                            type: 'get',
                            success: function(response){
                                select2_reload_simple('subcategoria_id', response);
                            }
                        });
                    }
                });

                // agregar precios
                let indice_compra = <?php echo e($indiceCompra); ?>;
                $('#btn-add_compra').click(function(){
                    add_precio_compra(indice_compra)
                    indice_compra++;
                });

                let indice_venta = <?php echo e($indiceVenta); ?>;
                $('#btn-add_venta').click(function(){
                    add_precio_venta(indice_venta)
                    indice_venta++;
                });

                // ================

            });
        </script>
    <?php $__env->stopSection(); ?>

<?php else: ?>
    <?php $__env->startSection('content'); ?>
        <?php echo $__env->make('errors.sin_permiso', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatcom\resources\views/inventarios/productos/electronica_computacion/productos_edit.blade.php ENDPATH**/ ?>