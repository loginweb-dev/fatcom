<?php $__env->startSection('page_title', 'Cajas'); ?>

<?php if(auth()->user()->hasPermission('browse_cajas')): ?>
    <?php $__env->startSection('page_header'); ?>
        <h1 class="page-title">
            <i class="voyager-treasure"></i> Cajas
        </h1>
        <?php if(!$abiertas): ?>
            <?php if(auth()->user()->hasPermission('add_cajas')): ?>
            <a  href="<?php echo e(route('cajas_create')); ?>" class="btn btn-success btn-add-new">
                <i class="voyager-plus"></i> <span>Añadir nueva</span>
            </a>
            <?php endif; ?>
        <?php endif; ?>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
        <div class="page-content">
            <div class="page-content browse container-fluid">
                <?php echo $__env->make('voyager::alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-bordered">
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="col-md-8"></div>
                                        <form id="form-search" class="form-search">
                                            <div class="input-group col-md-4">
                                                <input type="date" id="search_value" class="form-control" name="s" value="<?php echo e($value); ?>">
                                                <span class="input-group-btn">
                                                    <button class="btn btn-default" style="margin-top:0px;padding:8px" type="submit">
                                                        <i class="voyager-search"></i>
                                                    </button>
                                                </span>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <div class="table-responsive">
                                    <table id="dataTable" class="table table-bordered table-hover">
                                        <thead>
                                            <tr>
                                                <th><a href="#"></a></th>
                                                <th><a href="#">Descripción</a></th>
                                                
                                                <th><a href="#">Ingresos</a></th>
                                                <th><a href="#">Egresos</a></th>
                                                
                                                <th><a href="#">Apertura</a></th>
                                                <th><a href="#">Cierre</a></th>
                                                
                                                <th class="text-right">Acciones</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php setlocale(LC_ALL, 'es_ES'); ?>
                                            <?php $__empty_1 = true; $__currentLoopData = $cajas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($item->id); ?></td>
                                                <td><?php echo e($item->nombre); ?></td>
                                                
                                                <td><?php echo e($item->total_ingresos); ?> Bs.</td>
                                                <td><?php echo e($item->total_egresos); ?> Bs.</td>
                                                
                                                <td><?php echo e(strftime('%d-%B-%Y %H:%M', strtotime($item->fecha_apertura.' '.$item->hora_apertura))); ?><br><small><?php echo e(\Carbon\Carbon::parse($item->fecha_apertura.' '.$item->hora_apertura)->diffForHumans()); ?></small></td>
                                                <?php if($item->abierta == 1): ?>
                                                <td><b>No definido</b></td>
                                                <?php else: ?>
                                                <td><?php echo e(strftime('%d-%B-%Y %H:%M', strtotime($item->fecha_cierre.' '.$item->hora_cierre))); ?><br><small><?php echo e(\Carbon\Carbon::parse($item->fecha_cierre.' '.$item->hora_cierre)->diffForHumans()); ?></small></td>
                                                <?php endif; ?>
                                                
                                                <td class="no-sort no-click text-right" id="bread-actions">
                                                    <?php if($item->abierta == 1): ?>
                                                        <span class="label label-primary">Abierta</span>
                                                    <?php else: ?>
                                                        <span class="label label-danger">Cerrada</span>
                                                    <?php endif; ?>
                                                    <?php if(auth()->user()->hasPermission('read_cajas')): ?>
                                                    <a href="<?php echo e(route('cajas_view', ['id' => $item->id])); ?>" title="Ver" class="btn btn-sm btn-warning view">
                                                        <i class="voyager-eye"></i> <span class="hidden-xs hidden-sm">Ver</span>
                                                    </a>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="12"><br><center><h5>No existen cajas registradas.</h5></center></td>
                                            </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="col-md-12">
                                <div class="col-md-4">
                                    <p class="text-muted">Mostrando del <?php echo e($cajas->firstItem()); ?> al <?php echo e($cajas->lastItem()); ?> de <?php echo e($cajas->total()); ?> registros.</p>
                                </div>
                                <div class="col-md-8">
                                    <nav class="text-right">
                                        <?php echo e($cajas->links()); ?>

                                    </nav>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('css'); ?>
        <style>
            .select2{
                width: 200px
            }
        </style>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('javascript'); ?>
        <script>
            $(document).ready(function() {
                $('#search_key').select2();

                // enviar formulario de busqueda
                $('#form-search').on('submit', function(e){
                    e.preventDefault();
                    let valor = $("#search_value").val();
                    if(valor==''){
                        valor = 'all';
                    }
                    window.location = `<?php echo e(url('admin/cajas/buscar/${valor}')); ?>`;
                });

                // set valor de cerrar caja
                $('.btn-close').click(function(){
                    $('#modal_close input[name="id"]').val($(this).data('id'));
                });

            });

            // error al eliminar un ingreso si la caja ya cerro
            function mensaje_error(){
                toastr.error('No puede anular el egreso debido a que esta registrado a una caja que se encuentra cerrada.', 'Error');
            }
        </script>
    <?php $__env->stopSection(); ?>

<?php else: ?>
    <?php $__env->startSection('content'); ?>
        <?php echo $__env->make('errors.sin_permiso', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatcom\resources\views/cajas/cajas_index.blade.php ENDPATH**/ ?>