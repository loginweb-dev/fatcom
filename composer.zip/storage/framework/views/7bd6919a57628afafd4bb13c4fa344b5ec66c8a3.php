<div class="row" style="overflow-y: auto;height:370px">
    <div class="panel-group" id="accordion">
        <?php $__empty_1 = true; $__currentLoopData = $subcategorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item0): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                $class = '';
            ?>
            <div class="panel panel-default" style="margin:0px">
                <div class="panel-heading" data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo e($item0->id); ?>" style="cursor:pointer">
                    <h4 class="panel-title"><?php echo e($item0->nombre); ?></h4>
                </div>

                
                <div id="collapse<?php echo e($item0->id); ?>" class="panel-collapse collapse <?php echo e($class); ?>">
                    <div class="panel-body">
                        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item0->id==$item->subcategoria_id): ?>
                                <?php if(!$item->se_almacena || ($item->se_almacena && $item->stock > 0)): ?>
                                    <?php
                                        $imagen = (!empty($item->imagen)) ? url('storage').'/'.str_replace('.', '_small.', $item->imagen) : url('storage/productos/default.png');
                                    ?>
                                    <div class="card col-md-3 text-center" style="margin:5px 0px">
                                        <img class="card-img-top img-producto" id="producto-<?php echo e($item->id); ?>" style="width:130px;height:100px;cursor:pointer" src="<?php echo e($imagen); ?>" alt="<?php echo e($item->nombre); ?>"
                                        <?php if(!$item->se_almacena): ?> onclick="combinar_producto(<?php echo e($item->id); ?>, '<?php echo e($item->nombre); ?>')" <?php endif; ?>
                                        ondblclick="agregar_producto(<?php echo e($item->id); ?>)">

                                        <div class="card-body" style="padding: 4px">
                                            <h4 class="card-title" style="padding: 0px"> <label class="label label-primary"><?php echo e($item->nombre); ?></label> </h4>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <br>
            <h5 class="text-center">No existen productos en ésta categoria.</h5>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\fatcom\resources\views/ventas/ventas_productos_categoria.blade.php ENDPATH**/ ?>