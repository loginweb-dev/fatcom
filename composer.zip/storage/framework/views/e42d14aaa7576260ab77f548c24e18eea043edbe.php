<?php $__env->startSection('nombre_pagina'); ?>
    <title>Iniciar sesión</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    
    <br>
    <form method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>
        <div class="col-md-4 offset-md-4">
            <div class="card">
                <header class="card-header">
                    <a href="<?php echo e(route('register')); ?>" class="float-right btn btn-outline-primary">Registrarse</a>
                    <h4 class="card-title mb-4 mt-1">Iniciar sesión</h4>
                </header>
                <article class="card-body">
                    <p>
                        <a href="<?php echo e(url('login/google')); ?>" class="btn btn-block btn-danger btn-link-page"> <i class="fab fa-google"></i> &nbsp; Login via Google</a>
                        <a href="<?php echo e(url('login/facebook')); ?>" class="btn btn-block btn-facebook btn-link-page"> <i class="fab fa-facebook-f"></i> &nbsp; Login via facebook</a>
                    </p>
                    <hr>
                    <form>
                    <div class="form-group input-icon">
                        <i class="fa fa-user"></i>
                        <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                        <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="form-group input-icon">
                        <i class="fa fa-lock"></i>
                        <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="current-password">
                        <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div> <!-- form-group// -->
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary btn-block btn-link-page"> Inicicar sesión  </button>
                            </div>
                        </div>
                        <div class="col-md-6 text-right">
                            <?php if(Route::has('password.request')): ?>
                                <a class="small" href="<?php echo e(route('password.request')); ?>">
                                    Olvidaste tu contraseña?
                                </a>
                            <?php endif; ?>
                        </div>
                    </div> <!-- .row// -->
                </article>
            </div> <!-- card.// -->
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function(){
            $('.btn-link-page').click(function(){
                $(this).append(' <i class="fas fa-circle-notch fa-spin"></i>');
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatcom\resources\views/auth/login.blade.php ENDPATH**/ ?>