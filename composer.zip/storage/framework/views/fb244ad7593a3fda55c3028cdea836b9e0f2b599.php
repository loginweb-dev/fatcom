<?php $__env->startSection('meta-datos'); ?>
    <title>Carrito de compra - <?php echo e(setting('admin.title')); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('banner'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main id="contenido" class="col-md-7">
    <form id="form_carrito" name="form_carrito" action="<?php echo e(route('pedidos_store')); ?>" method="post">
        <div class="card">
            <div class="table-responsive">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="venta_tipo_id" value="3">
                <input type="hidden" name="cliente_id" value="<?php echo e($cliente_id); ?>">
                <table class="table table-hover shopping-cart-wrap">
                    <thead class="text-muted">
                    <tr>
                        
                        <th scope="col">Productos</th>
                        <th scope="col"></th>
                        <th scope="col">Monto</th>
                        <th scope="col" class="text-right" width="100">Acción</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php
                            $total = 0;
                            $cont = 0;
                            $envio_disponible = 0;
                        ?>
                        <?php $__empty_1 = true; $__currentLoopData = $carrito; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $imagen = ($item->imagen!='') ? str_replace('.', '_small.', $item->imagen) : 'productos/default.png';
                        ?>
                        <tr>
                            
                            <td>
                                <figure class="media">
                                    <div class="img-wrap link-page" onclick="ver_detalle('<?php echo e($item->slug); ?>')" title="Ver detalles"><img src="<?php echo e(url('storage').'/'.$imagen); ?>" class="img-thumbnail img-sm"></div>
                                    <figcaption class="media-body">
                                        <h5 class="title text-truncate text-primary"><?php echo e($item->nombre); ?></h5>
                                        <?php
                                            $precio_actual = $item->precio_venta;
                                            $precio_anterior = '';
                                            if($ofertas[$cont]){
                                                if($ofertas[$cont]->tipo_descuento=='porcentaje'){
                                                    $precio_actual -= ($precio_actual*($ofertas[$cont]->monto/100));
                                                }else{
                                                    $precio_actual -= $ofertas[$cont]->monto;
                                                }
                                                $precio_anterior = $item->moneda.' '.$item->precio_venta;
                                            }
                                        ?>
                                        <dl class="dlist-align small">
                                            <dt>Precio</dt>
                                            <dd>
                                                <var class="price text-info" id="label-precio<?php echo e($item->id); ?>"><?php echo e($item->moneda); ?> <?php echo e($precio_actual); ?></var>
                                                <input type="hidden" class="form-control input-precio" data-id="<?php echo e($item->id); ?>" name="precio[]" value="<?php echo e($precio_actual); ?>">
                                            </dd>
                                            <?php
                                                $costo_envio = '';
                                                foreach($disponibles as $envio){
                                                    if($item->id == $envio->id){
                                                        if(Auth::user()){
                                                            if(Auth::user()->localidad_id == $envio->localidad_id){
                                                                $costo_envio = $envio->costo_envio;
                                                                $envio_disponible++;
                                                            }
                                                        }else{
                                                            $costo_envio = $envio->costo_envio;
                                                            $envio_disponible++;
                                                        }
                                                    }
                                                }
                                            ?>
                                            <dt>Cantidad</dt>
                                            <dd><input type="number" <?php if($costo_envio === ''): ?> disabled <?php endif; ?> style="width:75px;padding:0px 10px" class="form-control" onchange="calcular_total(<?php echo e($item->id); ?>)" onkeyup="calcular_total(<?php echo e($item->id); ?>)" name="cantidad[]" id="input-cantidad<?php echo e($item->id); ?>" value="1" min="1" step="1"></dd>
                                            <dt>Costo de envío</dt>
                                            <dd>
                                                <b>
                                                    <?php if($costo_envio === ''): ?>
                                                    <label class="badge badge-danger">No disponible</label>
                                                    <?php else: ?>
                                                    <?php echo e($costo_envio > 0 ? 'Bs. '.$costo_envio : 'Gratis'); ?>

                                                    <?php endif; ?>
                                                </b>
                                                <input type="hidden" name="costo_envio[]" id="input-costo_envio<?php echo e($item->id); ?>" value="<?php echo e($costo_envio); ?>">
                                            </dd>
                                        </dl>
                                    </figcaption>
                                </figure>
                            </td>
                            <td>
                                <?php switch(setting('admin.modo_sistema')):
                                    case ('electronica_computacion'): ?>
                                        <dl class="dlist-align small">
                                            <dt>Marca</dt>
                                            <dd> <?php echo e($item->marca); ?></dd><br>
                                            <dt>Modelo</dt>
                                            <dd> <?php echo e($item->modelo); ?></dd><br>
                                            <?php if(!empty($item->garantia)): ?>
                                                <dt>Garantía</dt>
                                                <dd> <?php echo e($item->garantia); ?></dd><br>
                                            <?php endif; ?>
                                        </dl>
                                        <?php break; ?>
                                    <?php case ('restaurante'): ?>
                                        <dl>
                                            <dt>Descripción</dt>
                                            <dd><p><?php echo e($item->descripcion_small); ?> </p></dd>
                                        </dl>
                                        <?php break; ?>
                                    <?php default: ?>
                                        
                                <?php endswitch; ?>
                            </td>
                            <?php
                                $envio = $costo_envio != '' ? $costo_envio : 0; 
                                $total += $precio_actual + $envio;
                                $cont++;
                            ?>
                            <td>
                                <h5 class="text-dark" id="label-subtotal<?php echo e($item->id); ?>">Bs. <?php echo e(number_format($precio_actual + $envio, 2, ',', '')); ?></h5>
                                <input type="hidden" class="input-subtotal" id="input-subtotal<?php echo e($item->id); ?>" value="<?php echo e($precio_actual + $envio); ?>">
                            </td>
                            <td class="text-right">
                                <a href="<?php echo e(url('carrito/borrar').'/'.$item->id); ?>" class="btn btn-outline-danger link-page"> <span class="fa fa-trash"></span></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="text-center"><span>No se han agregados productos al carro.</span></td>
                        </tr>
                        <?php endif; ?>
                        <tr>
                            <td colspan="2"><b>Total</b></td>
                            <td colspan="2"><h4 id="label-total">Bs. <?php echo e(number_format($total, 2, '.', '')); ?></h4></td>
                            <input type="hidden" id="input-importe" name="importe" value="<?php echo e($total); ?>">
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <aside class="col-md-5">
        
        <?php if(Auth::user()): ?>
            <?php if(Auth::user()->localidad_id): ?>
                <?php
                    $tipo_negocio = (setting('admin.modo_sistema') == 'restaurante') ? 'Restaurante' : 'Tienda' 
                ?>
                <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link link-tab active" data-value="domicilio" id="pills-tab1-tab" data-toggle="pill" href="#pills-tab1" role="tab" aria-controls="pills-tab1" aria-selected="true">Entrega a Domicilio</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link link-tab" data-value="tienda" id="pills-tab2-tab" data-toggle="pill" href="#pills-tab2" role="tab" aria-controls="pills-tab2" aria-selected="false">Recoger en <?php echo e($tipo_negocio); ?></a>
                    </li>
                </ul>
                <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane fade show active" id="pills-tab1" role="tabpanel" aria-labelledby="pills-tab1-tab">
                        <div style="margin:2px">
                            <?php if(count($user_coords)>0): ?>
                                <h6 class="text-muted">Mis Ubicaciones:</h6>
                                <?php $__currentLoopData = $user_coords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <?php
                                        $descripcion = $item->descripcion;
                                        if(strlen($descripcion)>30){
                                            $descripcion = substr($descripcion, 0, 30).'...';
                                        }
                                    ?>
                                    <button type="button" class="btn btn-outline-primary btn-coor" data-id="<?php echo e($item->id); ?>" data-lat="<?php echo e($item->lat); ?>" data-lon="<?php echo e($item->lon); ?>" data-descripcion="<?php echo e($item->descripcion); ?>" data-toggle="tooltip" data-placement="top" title="<?php echo e($item->descripcion); ?>"><?php echo e($descripcion); ?></button>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <span>No tiene ubicaciones, crea una.</span>
                            <?php endif; ?>
                        </div>
                        <div id="map"></div>
                        <input type="hidden" name="lat" id="latitud" >
                        <input type="hidden" name="lon" id="longitud">
                        <input type="hidden" name="coordenada_id" id="input-coordenada_id">
                        <input type="hidden" name="tipo_entrega" id="input-tipo_entrega" value="domicilio">
                        <textarea name="descripcion" class="form-control" id="input-descripcion" rows="2" maxlength="200" placeholder="Datos descriptivos de su ubicación..."></textarea>
                    </div>
                    <div class="tab-pane fade" id="pills-tab2" role="tabpanel" aria-labelledby="pills-tab2-tab">
                        <div class="card">
                            
                            <div class="card-body">
                                <div id="contenedor_mapa">
                                    <div id="map2"></div>
                                </div>
                            </div>
                            <div class="card-footer text-muted">
                                <p>Puedes pasar en cualquie momento por nuestra tienda para recoger tu pedido.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="text-right">
                    <button type="button" class="btn btn-outline-success" id="btn-pasarela">Realizar pedido <span class="fa fa-shopping-cart"></span> </button>
                </div>
            <?php else: ?>
                <i>No has elegido la ciudad en la que te encuentras, por favor ingresa <a href="#"><b>aquí</b></a> para editar tu información.</i>
            <?php endif; ?>
        <?php else: ?>
            <div class="card">
                
                <div class="card-body">
                    <h5 class="card-title">Oops!... aún no has iniciado sesión</h5>
                    <p class="card-text">Para poder utilizar el servicio de pedidos en nuestra plataforma debes tener una sesión iniciada.</p>
                    <div class="text-center">
                        <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-primary">Iniciar sesión</a> o <a href="<?php echo e(route('register')); ?>" class="btn btn-outline-dark">Registrarse</a>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        
        <div class="modal modal-info fade" tabindex="-1" id="modal_confirmar" role="dialog">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">
                                <i class="fa fa-shopping-cart"></i> Elija la forma de pago
                            </h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        </div>
                        <div class="modal-body">
                            <div class="col-md-12">
                                <table width="100%" cellpadding="10">
                                    <?php
                                        $checked = 'checked';
                                    ?>
                                    <?php $__currentLoopData = $pasarela_pago; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><input type="radio" <?php echo e($checked); ?> <?php if($item->estado == 0): ?> disabled <?php endif; ?> name="tipo_pago"></td>
                                        <td><img src="<?php echo e(url('storage').'/'.$item->icono); ?>" width="80px" alt="icono"></td>
                                        <td><?php echo e($item->nombre); ?> <br> <b><?php echo e($item->descripcion); ?></b></td>
                                    </tr>
                                    <?php
                                        $checked = '';
                                    ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <input type="submit" class="btn btn-info pull-right delete-confirm"value="Confirmar">
                            <button type="button" class="btn btn-default pull-right" data-dismiss="modal">Cancelar</button>
                        </div>
                    </div>
                </div>
            </div>
        
    
    </aside>
    </form>
<?php $__env->stopSection(); ?>
<script>
    const cont_carrito = parseInt('<?php echo e($cont); ?>');
    function calcular_total(id){
        let cantidad = $('#input-cantidad'+id).val();
        $.get("<?php echo e(url('carrito/get_precio')); ?>/"+id+'/'+cantidad, function(data){
            $('#input-precio'+id).val(data.precio);
            $('#label-precio'+id).text(data.moneda+' '+data.precio);
            
            let costo_envio = $('#input-costo_envio'+id).val() != '' ? parseFloat($('#input-costo_envio'+id).val()) : 0;
            let precio = parseFloat(data.precio)
            let subtotal = (precio + costo_envio) * cantidad;
            
            $('#label-subtotal'+id).html('Bs. '+subtotal.toFixed(2));
            $('#input-subtotal'+id).val(subtotal);
            
            let total = 0;
            $('.input-subtotal').each(function(){
                total += parseFloat($(this).val());
            });
            $('#label-total').html('Bs. '+total.toFixed(2));
            $('#input-importe').val(total)
        
        });
    }

    // function enviar_carrito(){
    //     document.form_carrito.submit()
    // }
</script>


    
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.5.1/dist/leaflet.css" integrity="sha512-xwE/Az9zrjBIphAcBb3F6JVqxf46+CDLwfLMHloNu6KEQCAWi6HcDUbeOfBIptF7tcCzusKFjFw2yuvEpDL9wQ==" crossorigin=""/>
    <style>
        #map, #map2 {
            height: 300px;
        }
        .img-wrap{
            cursor: pointer;
        }
    </style>
    <script src="<?php echo e(url('ecommerce/js/jquery-2.0.0.min.js')); ?>" type="text/javascript"></script>
    <script src="https://unpkg.com/leaflet@1.5.1/dist/leaflet.js" integrity="sha512-GffPMF3RvMeYyc1LWMHtK8EbPv0iNZ8/oTtHPx9/cc2ILxQ+u905qIwdpULaqDkyBKgOaB57QTMg7ztg8Jm2Og==" crossorigin=""></script>
    <script src="<?php echo e(url('js/ubicacion_cliente.js')); ?>" type="text/javascript"></script>
    <script>
        let marcador = {};
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();

            $('.link-tab').click(function(){
                let tipo_entrega =$(this).data('value');
                $('#input-tipo_entrega').val(tipo_entrega);
            });

            // Mostrar modal de pasarela de pago
            $('#btn-pasarela').click(function(){
                if(<?php echo e($envio_disponible); ?> == <?php echo e(count($carrito)); ?>){
                    let descripcion = $('#input-descripcion').val();
                    if(descripcion != '' || $('#input-tipo_entrega').val() == 'tienda'){
                        $('#modal_confirmar').modal();
                    }else{
                        toastr.options = {"positionClass": "toast-top-right",}
                        $('#input-descripcion').focus()
                        toastr.warning('Debe proporcionar una descripción de su ubicación para su fácil localización', 'Advertencia');
                    }
                }else{
                    toastr.options = {"positionClass": "toast-top-right",}
                    toastr.error('Existe un producto en el carrito de compra que no está disponible en su ciudad, por favor eliminelo de la lista para completar el pedido.', 'Error');
                }
            });

            // Ver ubicacion de la tienda
            $('#pills-tab2-tab').click(function(){
                map2.remove();
                setTimeout(()=>{
                    $('#contenedor_mapa').html('<div id="map2"></div>');
                    map2 = L.map('map2').setView([<?php echo e($sucursal->latitud); ?>, <?php echo e($sucursal->longitud); ?>], 15);
                    var iconoBase = L.Icon.extend({ options: { iconSize: [40, 40], iconAnchor: [15, 35], popupAnchor: [0, -30] } });
                    let iconDelivery = new iconoBase({iconUrl: "<?php echo e(url('storage').'/'.str_replace('\\', '/', setting('empresa.logo'))); ?>"});
                    
                    L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw', {
                        maxZoom: 20,
                        attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, ' +
                            '<a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
                            'Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
                        id: 'mapbox.streets'
                    }).addTo(map2);

                    L.marker([<?php echo e($sucursal->latitud); ?>, <?php echo e($sucursal->longitud); ?>], {icon: iconDelivery}).addTo(map2)
                    .bindPopup("Ubicación de nuestra tienda").openPopup();
                }, 400);
            });
        });

        // Ver detalle de producto
        function ver_detalle(slug){
            window.location = '<?php echo e(url("detalle")); ?>/'+slug;
        }
    </script>


<?php echo $__env->make('ecommerce.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatcom\resources\views/ecommerce/carrito.blade.php ENDPATH**/ ?>