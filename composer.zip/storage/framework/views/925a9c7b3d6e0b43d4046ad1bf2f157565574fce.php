
<div class="modal fade" tabindex="-1" id="modal_load" data-backdrop="static" role="dialog">
    <div style="display: flex;justify-content: center;align-items: center;height:100%">
        <img src="<?php echo e(voyager_asset('images/load.gif')); ?>" width="80px" alt="">
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\fatcom\resources\views/partials/modal_load.blade.php ENDPATH**/ ?>