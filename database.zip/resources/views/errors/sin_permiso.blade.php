<div class="contenido text-center">
    <b class="error_number">403</b>
    <p class="error_description">Acceso denegado!</p>
</div>
<style>
    .contenido{
        margin: 50px 0px;
    }
    .error_number{
        font-size: 150px;
        font-weight: bold;
    }
    .error_description{
        margin-top: -50px;
        font-size: 40px;
        font-weight: bold;
    }
</style>
