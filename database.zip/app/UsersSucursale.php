<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class UsersSucursale extends Model
{
    protected $fillable = ['user_id', 'sucursal_id'];
}
