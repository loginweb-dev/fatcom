@extends('ecommerce.master')

@section('meta-datos')
    <title>Mis pedidos - {{setting('empresa.title')}}</title>
@endsection

@section('content')
    <div class="col-md-12 text-center bg-white padding-y-lg">
        <h1 class="display-4">OOPS!</h1>
        <h2 class="display-6">No se encontraron resultados.</h2>
    </div>
@endsection
