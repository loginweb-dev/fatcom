<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class ProductosInsumo extends Model
{
    
}
