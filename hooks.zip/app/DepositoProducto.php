<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class DepositoProducto extends Model
{
    
}
