<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class ProductoImagene extends Model
{
    
}
