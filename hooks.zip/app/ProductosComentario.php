<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class ProductosComentario extends Model
{
    
}
