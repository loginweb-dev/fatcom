{{-- modal de carga --}}
<div class="modal fade" tabindex="-1" id="modal_load" data-backdrop="static" role="dialog">
    <img src="{{voyager_asset('images/load.gif')}}" width="80px" style="left: 50%;top: 50%;position: absolute;" alt="">
</div>
